CREATE TABLE IF NOT EXISTS players (
  id BIGSERIAL PRIMARY KEY,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  phone TEXT NOT NULL DEFAULT '',
  password_salt TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  demo_coins BIGINT NOT NULL DEFAULT 0 CHECK (demo_coins >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS deposit_requests (
  id BIGSERIAL PRIMARY KEY,
  player_id BIGINT NOT NULL REFERENCES players(id) ON DELETE RESTRICT,
  amount BIGINT NOT NULL CHECK (amount > 0 AND amount <= 1000000),
  note TEXT NOT NULL DEFAULT '',
  sender_name TEXT NOT NULL DEFAULT '',
  sender_number TEXT NOT NULL DEFAULT '',
  trx_id TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'accepted', 'rejected')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  reviewed_at TIMESTAMPTZ,
  reviewed_by TEXT,
  admin_note TEXT NOT NULL DEFAULT ''
);

-- Add missing columns to existing databases
ALTER TABLE deposit_requests
ADD COLUMN IF NOT EXISTS sender_name TEXT NOT NULL DEFAULT '';

ALTER TABLE deposit_requests
ADD COLUMN IF NOT EXISTS sender_number TEXT NOT NULL DEFAULT '';

ALTER TABLE deposit_requests
ADD COLUMN IF NOT EXISTS trx_id TEXT NOT NULL DEFAULT '';

CREATE INDEX IF NOT EXISTS deposit_requests_status_created_idx
  ON deposit_requests (status, created_at DESC);

CREATE INDEX IF NOT EXISTS deposit_requests_player_created_idx
  ON deposit_requests (player_id, created_at DESC);

CREATE TABLE IF NOT EXISTS withdrawal_accounts (
  id BIGSERIAL PRIMARY KEY,
  player_id BIGINT NOT NULL REFERENCES players(id) ON DELETE RESTRICT,
  provider TEXT NOT NULL CHECK (provider IN ('easypaisa', 'jazzcash')),
  phone_number TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (player_id, provider)
);

CREATE TABLE IF NOT EXISTS withdrawal_requests (
  id BIGSERIAL PRIMARY KEY,
  player_id BIGINT NOT NULL REFERENCES players(id) ON DELETE RESTRICT,
  provider TEXT NOT NULL CHECK (provider IN ('easypaisa', 'jazzcash')),
  account_phone TEXT NOT NULL,
  amount BIGINT NOT NULL CHECK (amount > 0 AND amount <= 1000000),
  status TEXT NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending', 'accepted', 'rejected')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  reviewed_at TIMESTAMPTZ,
  reviewed_by TEXT,
  admin_note TEXT NOT NULL DEFAULT ''
);

CREATE INDEX IF NOT EXISTS withdrawal_requests_status_created_idx
  ON withdrawal_requests (status, created_at DESC);
CREATE INDEX IF NOT EXISTS withdrawal_requests_player_created_idx
  ON withdrawal_requests (player_id, created_at DESC);

CREATE TABLE IF NOT EXISTS coin_ledger (
  id BIGSERIAL PRIMARY KEY,
  player_id BIGINT NOT NULL REFERENCES players(id) ON DELETE RESTRICT,
  amount BIGINT NOT NULL CHECK (amount > 0),
  entry_type TEXT NOT NULL CHECK (
    entry_type IN (
      'deposit_accepted',
      'game_stake',
      'game_refund',
      'game_payout',
      'game_reward',
      'withdrawal_requested',
      'withdrawal_accepted',
      'withdrawal_rejected',
      'withdrawal_refund'
    )
  ),
  deposit_request_id BIGINT UNIQUE
    REFERENCES deposit_requests(id) ON DELETE RESTRICT,
  withdrawal_request_id BIGINT
    REFERENCES withdrawal_requests(id) ON DELETE RESTRICT,
  game_name TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE coin_ledger ALTER COLUMN deposit_request_id DROP NOT NULL;
ALTER TABLE coin_ledger ADD COLUMN IF NOT EXISTS game_name TEXT NOT NULL DEFAULT '';
ALTER TABLE coin_ledger
  ADD COLUMN IF NOT EXISTS withdrawal_request_id BIGINT
  REFERENCES withdrawal_requests(id) ON DELETE RESTRICT;
ALTER TABLE coin_ledger DROP CONSTRAINT IF EXISTS coin_ledger_entry_type_check;
ALTER TABLE coin_ledger ADD CONSTRAINT coin_ledger_entry_type_check
  CHECK (entry_type IN (
    'deposit_accepted',
    'game_stake',
    'game_refund',
    'game_payout',
    'game_reward',
    'withdrawal_requested',
    'withdrawal_accepted',
    'withdrawal_rejected',
    'withdrawal_refund'
  ));

CREATE TABLE IF NOT EXISTS game_bets (
  id BIGSERIAL PRIMARY KEY,
  player_id BIGINT NOT NULL REFERENCES players(id) ON DELETE RESTRICT,
  game_name TEXT NOT NULL CHECK (game_name IN ('aviator', 'crash')),
  amount BIGINT NOT NULL CHECK (amount > 0),
  status TEXT NOT NULL DEFAULT 'active'
    CHECK (status IN ('active', 'cashed_out', 'lost', 'cancelled')),
  payout BIGINT NOT NULL DEFAULT 0 CHECK (payout >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  settled_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS game_bets_player_created_idx
  ON game_bets (player_id, created_at DESC);

CREATE TABLE IF NOT EXISTS dragon_tiger_rounds (
  id BIGSERIAL PRIMARY KEY,
  status TEXT NOT NULL DEFAULT 'betting'
    CHECK (status IN ('betting', 'revealing', 'settled')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  betting_ends_at TIMESTAMPTZ NOT NULL,
  reveal_at TIMESTAMPTZ NOT NULL,
  settled_at TIMESTAMPTZ,
  dragon_rank TEXT,
  dragon_suit TEXT,
  tiger_rank TEXT,
  tiger_suit TEXT,
  winner TEXT CHECK (winner IN ('dragon', 'tiger', 'tie')),
  CHECK ((status = 'settled') = (winner IS NOT NULL))
);

CREATE INDEX IF NOT EXISTS dragon_tiger_rounds_status_id_idx
  ON dragon_tiger_rounds (status, id DESC);

CREATE TABLE IF NOT EXISTS dragon_tiger_bets (
  id BIGSERIAL PRIMARY KEY,
  round_id BIGINT NOT NULL REFERENCES dragon_tiger_rounds(id) ON DELETE RESTRICT,
  player_id BIGINT NOT NULL REFERENCES players(id) ON DELETE RESTRICT,
  pick TEXT NOT NULL CHECK (pick IN ('dragon', 'tiger', 'tie')),
  amount BIGINT NOT NULL CHECK (amount > 0 AND amount <= 1000000),
  status TEXT NOT NULL DEFAULT 'active'
    CHECK (status IN ('active', 'won', 'lost', 'push')),
  payout BIGINT NOT NULL DEFAULT 0 CHECK (payout >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  settled_at TIMESTAMPTZ,
  UNIQUE (round_id, player_id)
);

CREATE INDEX IF NOT EXISTS dragon_tiger_bets_round_idx
  ON dragon_tiger_bets (round_id, status);
CREATE INDEX IF NOT EXISTS dragon_tiger_bets_player_created_idx
  ON dragon_tiger_bets (player_id, created_at DESC);

CREATE TABLE IF NOT EXISTS lucky_wheel_settings (
  id SMALLINT PRIMARY KEY CHECK (id = 1),
  win_chance_percent NUMERIC(4, 1) NOT NULL DEFAULT 2.5
    CHECK (win_chance_percent >= 1.0 AND win_chance_percent <= 100.0),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE lucky_wheel_settings
  DROP CONSTRAINT IF EXISTS lucky_wheel_settings_win_chance_percent_check;
ALTER TABLE lucky_wheel_settings
  ALTER COLUMN win_chance_percent TYPE NUMERIC(4, 1),
  ADD CONSTRAINT lucky_wheel_settings_win_chance_percent_check
    CHECK (win_chance_percent >= 1.0 AND win_chance_percent <= 100.0);

INSERT INTO lucky_wheel_settings (id, win_chance_percent)
VALUES (1, 2.5)
ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS lucky_wheel_spins (
  id BIGSERIAL PRIMARY KEY,
  player_id BIGINT NOT NULL REFERENCES players(id) ON DELETE RESTRICT,
  bet BIGINT NOT NULL CHECK (bet >= 50 AND bet <= 1000 AND bet % 50 = 0),
  reward BIGINT NOT NULL DEFAULT 0 CHECK (reward >= 0),
  result_label TEXT NOT NULL CHECK (
    result_label IN ('LOSE', 'PLAY AGAIN', '1x', '2x', '5x', '10x', '20x', '50x', '100x')
  ),
  wheel_index SMALLINT NOT NULL CHECK (wheel_index >= 0 AND wheel_index <= 9),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE lucky_wheel_spins
  DROP CONSTRAINT IF EXISTS lucky_wheel_spins_result_label_check;
ALTER TABLE lucky_wheel_spins
  ADD CONSTRAINT lucky_wheel_spins_result_label_check
    CHECK (result_label IN (
      'LOSE', 'PLAY AGAIN', '1x', '2x', '5x', '10x', '20x', '50x', '100x'
    ));
ALTER TABLE lucky_wheel_spins
  DROP CONSTRAINT IF EXISTS lucky_wheel_spins_wheel_index_check;
ALTER TABLE lucky_wheel_spins
  ADD CONSTRAINT lucky_wheel_spins_wheel_index_check
    CHECK (wheel_index >= 0 AND wheel_index <= 9);

CREATE INDEX IF NOT EXISTS lucky_wheel_spins_player_created_idx
  ON lucky_wheel_spins (player_id, created_at DESC);
CREATE INDEX IF NOT EXISTS lucky_wheel_spins_created_idx
  ON lucky_wheel_spins (created_at DESC);

CREATE TABLE IF NOT EXISTS app_sessions (
  sid VARCHAR NOT NULL PRIMARY KEY,
  sess JSON NOT NULL,
  expire TIMESTAMP(6) NOT NULL
);

CREATE INDEX IF NOT EXISTS app_sessions_expire_idx ON app_sessions (expire);
