S999 Website — Replit Ready
================================

HOW TO RUN ON REPLIT
1. Create a new Replit using the Node.js template.
2. Upload/extract all files and folders from this project into the Replit project root.
   The root must contain: index.html, package.json, server.js, .replit, pages/, public/.
3. Press Run. Replit runs `npm start` and serves the website on its web preview.
4. The homepage is `/` (or `/index.html`).

Included browser games: Aviator, Crash, Dragon Tiger, 3 Patti, Slots, Chicken Road, Fishing,
Lucky Wheel, and Dice. The lobby includes a local Login/Register start screen, gold/red S999 styling, one card per game, and working category filters. Login/register data is stored locally in this browser only and is not secure authentication.
Keep the folder structure unchanged because pages use root-relative and relative asset paths.

IMPORTANT: This is a client-side practice game. Balances and outcomes are not secure
and are not suitable for real-money play. A production wallet or multiplayer game requires
server-side authentication, APIs, a database, and independently verified game logic.
