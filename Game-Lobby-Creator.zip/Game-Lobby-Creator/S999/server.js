const express = require("express");
const session = require("express-session");
const connectPgSimple = require("connect-pg-simple");
const { rateLimit } = require("express-rate-limit");
const helmet = require("helmet");
const crypto = require("node:crypto");
const { promisify } = require("node:util");
const path = require("node:path");
const pool = require("./db");
const {
  getDragonTigerState,
  placeDragonTigerBet,
  startDragonTigerRounds,
} = require("./dragon-tiger-rounds");

const app = express();
const ROOT = __dirname;
const PORT = Number(process.env.PORT || 5000);
const SESSION_SECRET = process.env.SESSION_SECRET;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const ADMIN_PATH = "/nimda312";
const MAX_REQUEST_COINS = 1_000_000;
const VIP_THRESHOLDS = [
  1_000, 5_000, 10_000, 20_000, 50_000,
  100_000, 500_000, 1_000_000, 1_000_000, 2_000_000,
];
const VIP_CHEST_REWARDS = [
  500, 1_000, 1_500, 2_500, 4_000,
  6_000, 8_000, 10_000, 15_000, 25_000,
];
const scrypt = promisify(crypto.scrypt);

function vipLevelForDeposit(totalDeposit) {
  let level = 0;
  for (let index = 0; index < VIP_THRESHOLDS.length; index += 1) {
    if (totalDeposit >= VIP_THRESHOLDS[index]) level = index + 1;
    else break;
  }
  return level;
}

function normalizeOriginHost(value) {
  if (typeof value !== "string" || !value.trim()) return "";
  const candidate = value.trim();
  try {
    return new URL(
      candidate.includes("://") ? candidate : `https://${candidate}`,
    ).host.toLowerCase();
  } catch {
    return "";
  }
}

const configuredOriginHosts = new Set(
  [process.env.REPLIT_DEV_DOMAIN, process.env.REPLIT_DOMAINS]
    .flatMap((value) => (value || "").split(","))
    .map(normalizeOriginHost)
    .filter(Boolean),
);

if (process.env.REPLIT_DEV_DOMAIN && Number.isSafeInteger(PORT) && PORT > 0) {
  try {
    const developmentHostname = new URL(
      `https://${normalizeOriginHost(process.env.REPLIT_DEV_DOMAIN)}`,
    ).hostname.toLowerCase();
    configuredOriginHosts.add(`${developmentHostname}:${PORT}`);
  } catch {
    // Ignore an invalid optional development domain.
  }
}

if (!SESSION_SECRET) {
  throw new Error("SESSION_SECRET is required to sign secure sessions.");
}

app.set("trust proxy", 1);
app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "20kb" }));
app.use((req, _res, next) => {
  if (!req.body || typeof req.body !== "object" || Array.isArray(req.body)) {
    req.body = {};
  }
  next();
});

const PgSession = connectPgSimple(session);
app.use(
  session({
    name: "s999.sid",
    secret: SESSION_SECRET,
    store: new PgSession({
      pool,
      tableName: "app_sessions",
      createTableIfMissing: false,
      pruneSessionInterval: 15,
    }),
    resave: false,
    saveUninitialized: false,
    rolling: true,
    cookie: {
      httpOnly: true,
      secure: "auto",
      sameSite: "lax",
      maxAge: 8 * 60 * 60 * 1000,
    },
  }),
);

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: "draft-8",
  legacyHeaders: false,
  message: { error: "Too many attempts. Please try again later." },
});

const adminLoginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 5,
  standardHeaders: "draft-8",
  legacyHeaders: false,
  message: { error: "Too many admin login attempts. Please try again later." },
});

const gameActionLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 120,
  standardHeaders: "draft-8",
  legacyHeaders: false,
  message: { error: "Too many game actions. Please slow down." },
});

const wheelSpinLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 20,
  standardHeaders: "draft-8",
  legacyHeaders: false,
  message: { error: "Please wait before spinning again." },
});

const depositRequestLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  limit: 10,
  standardHeaders: "draft-8",
  legacyHeaders: false,
  message: { error: "Too many requests. Please try again later." },
});

const withdrawalRequestLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  limit: 10,
  standardHeaders: "draft-8",
  legacyHeaders: false,
  message: { error: "Too many withdrawal requests. Please try again later." },
});

app.use("/api", (req, res, next) => {
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) return next();
  const origin = req.get("origin");
  try {
    const originUrl = new URL(origin || "");
    const originHost = originUrl.host.toLowerCase();
    const forwardedHost = req.get("x-forwarded-host")?.split(",")[0];
    const requestHosts = [
      // Replit's proxy may omit the externally mapped port from this header.
      normalizeOriginHost(forwardedHost),
      normalizeOriginHost(req.get("host")),
      normalizeOriginHost(req.hostname),
    ].filter(Boolean);
    const allowedHosts = new Set([...requestHosts, ...configuredOriginHosts]);

    if (
      !["http:", "https:"].includes(originUrl.protocol) ||
      !allowedHosts.has(originHost)
    ) {
      return res.status(403).json({ error: "Request origin was not allowed." });
    }
  } catch {
    return res.status(403).json({ error: "Request origin was not allowed." });
  }
  next();
});

function asyncRoute(handler) {
  return (req, res, next) => Promise.resolve(handler(req, res, next)).catch(next);
}

function cleanText(value, maxLength) {
  return typeof value === "string" ? value.trim().slice(0, maxLength) : "";
}

function validEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value) && value.length <= 254;
}

function validWithdrawalProvider(value) {
  return value === "easypaisa" || value === "jazzcash";
}

function normalizePakistanMobile(value) {
  if (typeof value !== "string") return "";
  const digits = value.replace(/\D/g, "");
  const normalized = digits.startsWith("03") && digits.length === 11
    ? `+92${digits.slice(1)}`
    : digits.startsWith("923") && digits.length === 12
      ? `+${digits}`
      : "";
  return /^\+923\d{9}$/.test(normalized) ? normalized : "";
}

function safeSecretCompare(candidate, expected) {
  if (typeof candidate !== "string" || typeof expected !== "string") return false;
  const candidateDigest = crypto.createHash("sha256").update(candidate).digest();
  const expectedDigest = crypto.createHash("sha256").update(expected).digest();
  return crypto.timingSafeEqual(candidateDigest, expectedDigest);
}

function regenerateSession(req) {
  return new Promise((resolve, reject) => {
    req.session.regenerate((error) => (error ? reject(error) : resolve()));
  });
}

function saveSession(req) {
  return new Promise((resolve, reject) => {
    req.session.save((error) => (error ? reject(error) : resolve()));
  });
}

function destroySession(req) {
  return new Promise((resolve) => {
    if (!req.session) return resolve();
    req.session.destroy(() => resolve());
  });
}

function clearSessionCookie(req, res) {
  res.clearCookie("s999.sid", {
    httpOnly: true,
    sameSite: "lax",
    secure: req.secure,
  });
}

function publicPlayer(row) {
  return {
    id: Number(row.id),
    fullName: row.full_name,
    email: row.email,
    demoCoins: Number(row.demo_coins),
  };
}

async function requirePlayer(req, res, next) {
  const id = Number(req.session.playerId);
  if (!Number.isSafeInteger(id) || id < 1) {
    return res.status(401).json({ error: "Please log in to continue." });
  }
  try {
    const result = await pool.query(
      "SELECT id, full_name, email, demo_coins::text AS demo_coins FROM players WHERE id = $1",
      [id],
    );
    if (!result.rows[0]) {
      await destroySession(req);
      clearSessionCookie(req, res);
      return res.status(401).json({ error: "Please log in to continue." });
    }
    req.player = result.rows[0];
    next();
  } catch (error) {
    next(error);
  }
}

function requireAdmin(req, res, next) {
  if (req.session.isAdmin !== true) {
    return res.status(401).json({ error: "Admin login required." });
  }
  next();
}

async function setPlayerSession(req, playerId, rememberMe) {
  await regenerateSession(req);
  req.session.playerId = Number(playerId);
  req.session.cookie.maxAge = rememberMe
    ? 30 * 24 * 60 * 60 * 1000
    : 8 * 60 * 60 * 1000;
  await saveSession(req);
}

app.get("/api/health", (_req, res) => res.json({ status: "ok" }));

app.get("/api/auth/me", asyncRoute(async (req, res) => {
  res.set("Cache-Control", "no-store");
  const id = Number(req.session.playerId);
  if (!Number.isSafeInteger(id) || id < 1) {
    return res.json({ authenticated: false });
  }
  const result = await pool.query(
    "SELECT id, full_name, email, demo_coins::text AS demo_coins FROM players WHERE id = $1",
    [id],
  );
  if (!result.rows[0]) {
    await destroySession(req);
    clearSessionCookie(req, res);
    return res.json({ authenticated: false });
  }
  res.json({ authenticated: true, user: publicPlayer(result.rows[0]) });
}));

app.get("/api/profile/summary", requirePlayer, asyncRoute(async (req, res) => {
  const result = await pool.query(
    `SELECT
       COALESCE((
         SELECT SUM(amount)
         FROM coin_ledger
         WHERE player_id = $1 AND entry_type = 'deposit_accepted'
       ), 0)::text AS total_deposit,
       (
         SELECT COUNT(*)::int
         FROM game_bets
         WHERE player_id = $1 AND status <> 'cancelled'
       ) + (
         SELECT COUNT(*)::int
         FROM coin_ledger
         WHERE player_id = $1
           AND entry_type IN ('game_stake', 'game_payout', 'game_reward')
           AND game_name NOT IN ('aviator', 'crash')
            AND game_name NOT LIKE 'vip-chest-vip-%'
           AND game_name <> ''
       ) AS games_played,
       COALESCE((
         SELECT SUM(amount)
         FROM coin_ledger
         WHERE player_id = $1
           AND entry_type = 'game_reward'
           AND game_name LIKE 'vip-chest-vip-%'
       ), 0)::text AS total_bonus`,
    [req.player.id],
  );
  res.set("Cache-Control", "no-store");
  res.json({
    id: String(req.player.id),
    fullName: req.player.full_name,
    demoCoins: Number(req.player.demo_coins),
    totalDeposit: Number(result.rows[0].total_deposit),
    totalBonus: Number(result.rows[0].total_bonus),
    shareBonus: 0,
    gamesPlayed: Number(result.rows[0].games_played),
  });
}));

app.get("/api/vip/rewards", requirePlayer, asyncRoute(async (req, res) => {
  const result = await pool.query(
    `SELECT
       COALESCE(SUM(amount) FILTER (
         WHERE entry_type = 'deposit_accepted'
       ), 0)::text AS total_deposit,
       ARRAY_AGG(DISTINCT game_name) FILTER (
         WHERE entry_type = 'game_reward'
           AND game_name LIKE 'vip-chest-vip-%'
       ) AS claimed_chests
     FROM coin_ledger
     WHERE player_id = $1`,
    [req.player.id],
  );
  const totalDeposit = Number(result.rows[0].total_deposit);
  const vipLevel = vipLevelForDeposit(totalDeposit);
  const claimedChests = new Set(result.rows[0].claimed_chests || []);

  res.set("Cache-Control", "no-store");
  res.json({
    vipLevel,
    totalDeposit,
    tiers: VIP_CHEST_REWARDS.map((amount, index) => {
      const level = index + 1;
      const claimed = claimedChests.has(`vip-chest-vip-${level}`);
      return {
        level,
        amount,
        requiredDeposit: VIP_THRESHOLDS[index],
        status: level > vipLevel ? "locked" : claimed ? "claimed" : "available",
      };
    }),
  });
}));

app.post("/api/vip/rewards/:level/claim", requirePlayer, gameActionLimiter, asyncRoute(async (req, res) => {
  const level = Number(req.params.level);
  if (!Number.isSafeInteger(level) || level < 1 || level > VIP_CHEST_REWARDS.length) {
    return res.status(400).json({ error: "Invalid VIP chest level." });
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const playerResult = await client.query(
      "SELECT demo_coins::text AS demo_coins FROM players WHERE id = $1 FOR UPDATE",
      [req.player.id],
    );
    if (!playerResult.rows[0]) {
      await client.query("ROLLBACK");
      return res.status(404).json({ error: "Player account not found." });
    }

    const depositResult = await client.query(
      `SELECT COALESCE(SUM(amount), 0)::text AS total_deposit
       FROM coin_ledger
       WHERE player_id = $1 AND entry_type = 'deposit_accepted'`,
      [req.player.id],
    );
    const vipLevel = vipLevelForDeposit(Number(depositResult.rows[0].total_deposit));
    if (level > vipLevel) {
      await client.query("ROLLBACK");
      return res.status(409).json({
        error: `VIP ${level} is still locked. Admin-approved deposits unlock this chest.`,
      });
    }

    const gameName = `vip-chest-vip-${level}`;
    const existingClaim = await client.query(
      `SELECT 1
       FROM coin_ledger
       WHERE player_id = $1
         AND entry_type = 'game_reward'
         AND game_name = $2
       LIMIT 1`,
      [req.player.id, gameName],
    );
    if (existingClaim.rowCount) {
      await client.query("COMMIT");
      return res.json({
        ok: true,
        alreadyClaimed: true,
        vipLevel,
        demoCoins: Number(playerResult.rows[0].demo_coins),
      });
    }

    const amount = VIP_CHEST_REWARDS[level - 1];
    const balanceResult = await client.query(
      `UPDATE players
       SET demo_coins = demo_coins + $1
       WHERE id = $2
       RETURNING demo_coins::text AS demo_coins`,
      [amount, req.player.id],
    );
    await client.query(
      `INSERT INTO coin_ledger (player_id, amount, entry_type, game_name)
       VALUES ($1, $2, 'game_reward', $3)`,
      [req.player.id, amount, gameName],
    );
    await client.query("COMMIT");
    res.json({
      ok: true,
      alreadyClaimed: false,
      claimedLevel: level,
      amount,
      vipLevel,
      demoCoins: Number(balanceResult.rows[0].demo_coins),
    });
  } catch (error) {
    await client.query("ROLLBACK").catch(() => {});
    throw error;
  } finally {
    client.release();
  }
}));

app.post("/api/auth/register", loginLimiter, asyncRoute(async (req, res) => {
  const fullName = cleanText(req.body.fullName, 80);
  const email = cleanText(req.body.email, 254).toLowerCase();
  const phone = cleanText(req.body.phone, 32);
  const password = typeof req.body.password === "string" ? req.body.password : "";
  const rememberMe = req.body.rememberMe === true;

  if (fullName.length < 2 || !validEmail(email) || phone.length < 5) {
    return res.status(400).json({ error: "Enter a valid name, email, and phone number." });
  }
  if (password.length < 8 || password.length > 256) {
    return res.status(400).json({ error: "Password must be at least 8 characters." });
  }

  const salt = crypto.randomBytes(16).toString("hex");
  const hash = (await scrypt(password, salt, 64)).toString("hex");
  try {
    const result = await pool.query(
      `INSERT INTO players (full_name, email, phone, password_salt, password_hash)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id, full_name, email, demo_coins::text AS demo_coins`,
      [fullName, email, phone, salt, hash],
    );
    await setPlayerSession(req, result.rows[0].id, rememberMe);
    res.status(201).json({ user: publicPlayer(result.rows[0]) });
  } catch (error) {
    if (error.code === "23505") {
      return res.status(409).json({ error: "An account with this email already exists." });
    }
    throw error;
  }
}));

app.post("/api/auth/login", loginLimiter, asyncRoute(async (req, res) => {
  const identifier = cleanText(req.body.username || req.body.email, 254).toLowerCase();
  const password = typeof req.body.password === "string" ? req.body.password : "";
  const rememberMe = req.body.rememberMe === true;
  if (!identifier || !password) {
    return res.status(400).json({ error: "Enter your email and password." });
  }

  const result = await pool.query(
    `SELECT id, full_name, email, demo_coins::text AS demo_coins,
            password_salt, password_hash
     FROM players WHERE LOWER(email) = $1`,
    [identifier],
  );
  const player = result.rows[0];
  const salt = player?.password_salt || "s999-invalid-login-salt";
  const expected = player?.password_hash || "0".repeat(128);
  const actual = (await scrypt(password, salt, 64)).toString("hex");
  const valid = safeSecretCompare(actual, expected);
  if (!player || !valid) {
    return res.status(401).json({ error: "Email or password is incorrect." });
  }

  await setPlayerSession(req, player.id, rememberMe);
  res.json({ user: publicPlayer(player) });
}));

app.post("/api/auth/logout", asyncRoute(async (req, res) => {
  await destroySession(req);
  clearSessionCookie(req, res);
  res.json({ ok: true });
}));

app.get("/api/wallet", requirePlayer, asyncRoute(async (req, res) => {
  await pool.query(
    `UPDATE game_bets SET status = 'lost', settled_at = NOW()
     WHERE player_id = $1 AND status = 'active'
       AND created_at < NOW() - INTERVAL '10 minutes'`,
    [req.player.id],
  );
  const activity = await pool.query(
    `SELECT cl.amount::text AS amount, cl.entry_type, cl.game_name, cl.created_at,
            wr.provider, wr.status AS withdrawal_status
     FROM coin_ledger cl
     LEFT JOIN withdrawal_requests wr ON wr.id = cl.withdrawal_request_id
     WHERE cl.player_id = $1
     ORDER BY cl.created_at DESC LIMIT 20`,
    [req.player.id],
  );
  res.set("Cache-Control", "no-store");
  res.json({
    demoCoins: Number(req.player.demo_coins),
    activity: activity.rows.map((item) => ({
      amount: Number(item.amount),
      createdAt: item.created_at,
      label: item.entry_type === "deposit_accepted"
        ? `Approved Demo Coin request +${Number(item.amount).toLocaleString()}`
        : item.entry_type === "withdrawal_requested"
          ? `${item.provider} Demo Coin withdrawal ${item.withdrawal_status || "pending"} −${Number(item.amount).toLocaleString()}`
          : item.entry_type === "withdrawal_accepted"
            ? `${item.provider} Demo Coin withdrawal accepted −${Number(item.amount).toLocaleString()}`
            : item.entry_type === "withdrawal_rejected"
              ? `${item.provider} Demo Coin withdrawal rejected −${Number(item.amount).toLocaleString()}`
              : item.entry_type === "withdrawal_refund"
                ? `${item.provider} Demo Coin withdrawal refunded +${Number(item.amount).toLocaleString()}`
        : item.entry_type === "game_stake"
          ? `${item.game_name} bet −${Number(item.amount).toLocaleString()}`
          : item.entry_type === "game_refund"
            ? `${item.game_name} bet refunded +${Number(item.amount).toLocaleString()}`
            : item.entry_type === "game_payout"
              ? `${item.game_name} cashout +${Number(item.amount).toLocaleString()}`
            : item.entry_type === "game_reward" && item.game_name.startsWith("vip-chest-vip-")
              ? `VIP ${item.game_name.slice("vip-chest-vip-".length)} treasure claimed +${Number(item.amount).toLocaleString()}`
              : `${item.game_name} reward +${Number(item.amount).toLocaleString()}`,
    })),
  });
}));

app.get("/api/deposit-requests", requirePlayer, asyncRoute(async (req, res) => {
  const result = await pool.query(
    `SELECT id, amount::text AS amount, note,
            sender_name, sender_number, trx_id,
            status, created_at, reviewed_at, admin_note
     FROM deposit_requests
     WHERE player_id = $1
     ORDER BY created_at DESC
     LIMIT 50`,
    [req.player.id],
  );

  res.set("Cache-Control", "no-store");

  res.json({
    requests: result.rows.map((row) => ({
      id: Number(row.id),
      amount: Number(row.amount),
      note: row.note,
      senderName: row.sender_name,
      senderNumber: row.sender_number,
      trxId: row.trx_id,
      status: row.status,
      createdAt: row.created_at,
      reviewedAt: row.reviewed_at,
      adminNote: row.admin_note,
    })),
  });
}));

app.post("/api/deposit-requests", requirePlayer, depositRequestLimiter, asyncRoute(async (req, res) => {
  const amount = Number(req.body.amount);
  const senderName = cleanText(req.body.senderName, 100);
  const senderNumber = cleanText(req.body.senderNumber, 30);
  const trxId = cleanText(req.body.trxId, 100);

  if (!Number.isSafeInteger(amount) || amount < 1 || amount > MAX_REQUEST_COINS) {
    return res.status(400).json({
      error: `Enter an amount from 1 to ${MAX_REQUEST_COINS.toLocaleString()} Demo Coins.`
    });
  }

  if (!senderName || !senderNumber || !trxId) {
    return res.status(400).json({
      error: "Sender Name, Sender Number and TRX ID are required."
    });
  }

  const pending = await pool.query(
    "SELECT COUNT(*)::int AS count FROM deposit_requests WHERE player_id = $1 AND status = 'pending'",
    [req.player.id],
  );

  if (pending.rows[0].count >= 3) {
    return res.status(429).json({
      error: "You already have 3 pending requests. Wait for a review first."
    });
  }

  const result = await pool.query(
    `INSERT INTO deposit_requests
      (player_id, amount, sender_name, sender_number, trx_id)
     VALUES ($1, $2, $3, $4, $5)
     RETURNING id, amount::text AS amount,
               sender_name, sender_number, trx_id,
               status, created_at`,
    [req.player.id, amount, senderName, senderNumber, trxId],
  );

  const row = result.rows[0];

  res.status(201).json({
    request: {
      id: Number(row.id),
      amount: Number(row.amount),
      senderName: row.sender_name,
      senderNumber: row.sender_number,
      trxId: row.trx_id,
      status: row.status,
      createdAt: row.created_at,
    },
  });
}));

app.get("/api/wallet/accounts", requirePlayer, asyncRoute(async (req, res) => {
  const result = await pool.query(
    `SELECT provider, phone_number, updated_at
     FROM withdrawal_accounts
     WHERE player_id = $1
     ORDER BY provider`,
    [req.player.id],
  );
  res.set("Cache-Control", "no-store");
  res.json({
    accounts: result.rows.map((row) => ({
      provider: row.provider,
      phoneNumber: row.phone_number,
      updatedAt: row.updated_at,
    })),
  });
}));

app.put("/api/wallet/accounts/:provider", requirePlayer, asyncRoute(async (req, res) => {
  const provider = cleanText(req.params.provider, 16).toLowerCase();
  const phoneNumber = normalizePakistanMobile(req.body.phoneNumber);
  if (!validWithdrawalProvider(provider)) {
    return res.status(400).json({ error: "Choose EasyPaisa or JazzCash." });
  }
  if (!phoneNumber) {
    return res.status(400).json({ error: "Enter a valid Pakistan mobile number, such as 03XXXXXXXXX." });
  }

  const result = await pool.query(
    `INSERT INTO withdrawal_accounts (player_id, provider, phone_number)
     VALUES ($1, $2, $3)
     ON CONFLICT (player_id, provider)
     DO UPDATE SET phone_number = EXCLUDED.phone_number, updated_at = NOW()
     RETURNING provider, phone_number, updated_at`,
    [req.player.id, provider, phoneNumber],
  );
  const row = result.rows[0];
  res.set("Cache-Control", "no-store");
  res.json({
    account: {
      provider: row.provider,
      phoneNumber: row.phone_number,
      updatedAt: row.updated_at,
    },
  });
}));

app.get("/api/withdrawal-requests", requirePlayer, asyncRoute(async (req, res) => {
  const result = await pool.query(
    `SELECT id, provider, account_phone, amount::text AS amount, status,
            created_at, reviewed_at, admin_note
     FROM withdrawal_requests
     WHERE player_id = $1
     ORDER BY created_at DESC
     LIMIT 50`,
    [req.player.id],
  );
  res.set("Cache-Control", "no-store");
  res.json({
    requests: result.rows.map((row) => ({
      id: Number(row.id),
      provider: row.provider,
      accountPhone: row.account_phone,
      amount: Number(row.amount),
      status: row.status,
      createdAt: row.created_at,
      reviewedAt: row.reviewed_at,
      adminNote: row.admin_note,
    })),
  });
}));

app.post("/api/withdrawal-requests", requirePlayer, withdrawalRequestLimiter, asyncRoute(async (req, res) => {
  const provider = cleanText(req.body.provider, 16).toLowerCase();
  const amount = Number(req.body.amount);
  if (!validWithdrawalProvider(provider)) {
    return res.status(400).json({ error: "Choose EasyPaisa or JazzCash." });
  }
  if (!Number.isSafeInteger(amount) || amount < 1 || amount > MAX_REQUEST_COINS) {
    return res.status(400).json({ error: `Enter an amount from 1 to ${MAX_REQUEST_COINS.toLocaleString()} Demo Coins.` });
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const accountResult = await client.query(
      `SELECT phone_number FROM withdrawal_accounts
       WHERE player_id = $1 AND provider = $2`,
      [req.player.id, provider],
    );
    if (!accountResult.rowCount) {
      await client.query("ROLLBACK");
      return res.status(409).json({ error: "Link this provider's mobile number before requesting a withdrawal." });
    }

    const playerResult = await client.query(
      "SELECT demo_coins::text AS demo_coins FROM players WHERE id = $1 FOR UPDATE",
      [req.player.id],
    );
    const balance = Number(playerResult.rows[0]?.demo_coins || 0);
    if (amount > balance) {
      await client.query("ROLLBACK");
      return res.status(409).json({ error: "Not enough Demo Coins for this request." });
    }

    const pendingResult = await client.query(
      `SELECT COUNT(*)::int AS count
       FROM withdrawal_requests
       WHERE player_id = $1 AND status = 'pending'`,
      [req.player.id],
    );
    if (pendingResult.rows[0].count >= 3) {
      await client.query("ROLLBACK");
      return res.status(429).json({ error: "You already have 3 pending withdrawal requests." });
    }

    const requestResult = await client.query(
      `INSERT INTO withdrawal_requests (player_id, provider, account_phone, amount)
       VALUES ($1, $2, $3, $4)
       RETURNING id, provider, account_phone, amount::text AS amount, status, created_at`,
      [req.player.id, provider, accountResult.rows[0].phone_number, amount],
    );
    const balanceResult = await client.query(
      `UPDATE players SET demo_coins = demo_coins - $1
       WHERE id = $2 RETURNING demo_coins::text AS demo_coins`,
      [amount, req.player.id],
    );
    await client.query(
      `INSERT INTO coin_ledger (player_id, amount, entry_type, withdrawal_request_id)
       VALUES ($1, $2, 'withdrawal_requested', $3)`,
      [req.player.id, amount, requestResult.rows[0].id],
    );
    await client.query("COMMIT");

    const row = requestResult.rows[0];
    res.status(201).json({
      request: {
        id: Number(row.id),
        provider: row.provider,
        accountPhone: row.account_phone,
        amount: Number(row.amount),
        status: row.status,
        createdAt: row.created_at,
      },
      demoCoins: Number(balanceResult.rows[0].demo_coins),
    });
  } catch (error) {
    await client.query("ROLLBACK").catch(() => {});
    throw error;
  } finally {
    client.release();
  }
}));

app.post("/api/games/bets", requirePlayer, gameActionLimiter, asyncRoute(async (req, res) => {
  const gameName = cleanText(req.body.game, 16);
  const amount = Number(req.body.amount);
  if (!["aviator", "crash"].includes(gameName)) {
    return res.status(400).json({ error: "Unknown game." });
  }
  const minimumBet = gameName === "crash" ? 5 : 1;
  if (!Number.isSafeInteger(amount) || amount < minimumBet || amount > MAX_REQUEST_COINS) {
    return res.status(400).json({
      error: `Enter a valid whole-number bet of at least ${minimumBet} Demo Coins.`,
    });
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const playerResult = await client.query(
      "SELECT demo_coins::text AS demo_coins FROM players WHERE id = $1 FOR UPDATE",
      [req.player.id],
    );
    const balance = Number(playerResult.rows[0]?.demo_coins || 0);
    if (amount > balance) {
      await client.query("ROLLBACK");
      return res.status(409).json({ error: "Not enough Demo Coins." });
    }
    const betResult = await client.query(
      `INSERT INTO game_bets (player_id, game_name, amount)
       VALUES ($1, $2, $3) RETURNING id`,
      [req.player.id, gameName, amount],
    );
    const balanceResult = await client.query(
      `UPDATE players SET demo_coins = demo_coins - $1
       WHERE id = $2 RETURNING demo_coins::text AS demo_coins`,
      [amount, req.player.id],
    );
    await client.query(
      `INSERT INTO coin_ledger (player_id, amount, entry_type, game_name)
       VALUES ($1, $2, 'game_stake', $3)`,
      [req.player.id, amount, gameName],
    );
    await client.query("COMMIT");
    res.status(201).json({
      betId: Number(betResult.rows[0].id),
      amount,
      demoCoins: Number(balanceResult.rows[0].demo_coins),
    });
  } catch (error) {
    await client.query("ROLLBACK").catch(() => {});
    throw error;
  } finally {
    client.release();
  }
}));

app.post("/api/games/bets/:id/cancel", requirePlayer, gameActionLimiter, asyncRoute(async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id) || id < 1) {
    return res.status(400).json({ error: "Invalid bet ID." });
  }
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const betResult = await client.query(
      `SELECT id, amount::text AS amount, game_name, status
       FROM game_bets WHERE id = $1 AND player_id = $2 FOR UPDATE`,
      [id, req.player.id],
    );
    const bet = betResult.rows[0];
    if (!bet) {
      await client.query("ROLLBACK");
      return res.status(404).json({ error: "Bet not found." });
    }
    if (bet.status !== "active") {
      await client.query("ROLLBACK");
      return res.status(409).json({ error: "This bet has already been settled." });
    }
    const amount = Number(bet.amount);
    const balanceResult = await client.query(
      `UPDATE players SET demo_coins = demo_coins + $1
       WHERE id = $2 RETURNING demo_coins::text AS demo_coins`,
      [amount, req.player.id],
    );
    await client.query(
      "UPDATE game_bets SET status = 'cancelled', settled_at = NOW() WHERE id = $1",
      [id],
    );
    await client.query(
      `INSERT INTO coin_ledger (player_id, amount, entry_type, game_name)
       VALUES ($1, $2, 'game_refund', $3)`,
      [req.player.id, amount, bet.game_name],
    );
    await client.query("COMMIT");
    res.json({ ok: true, demoCoins: Number(balanceResult.rows[0].demo_coins) });
  } catch (error) {
    await client.query("ROLLBACK").catch(() => {});
    throw error;
  } finally {
    client.release();
  }
}));

app.post("/api/games/bets/:id/cashout", requirePlayer, gameActionLimiter, asyncRoute(async (req, res) => {
  const id = Number(req.params.id);
  const multiplier = Number(req.body.multiplier);
  if (!Number.isSafeInteger(id) || id < 1 ||
      !Number.isFinite(multiplier) || multiplier < 1 || multiplier > 200) {
    return res.status(400).json({ error: "Invalid cashout." });
  }
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const betResult = await client.query(
      `SELECT id, amount::text AS amount, game_name, status
       FROM game_bets WHERE id = $1 AND player_id = $2 FOR UPDATE`,
      [id, req.player.id],
    );
    const bet = betResult.rows[0];
    if (!bet) {
      await client.query("ROLLBACK");
      return res.status(404).json({ error: "Bet not found." });
    }
    if (bet.status !== "active") {
      await client.query("ROLLBACK");
      return res.status(409).json({ error: "This bet has already been settled." });
    }
    const payout = Math.floor(Number(bet.amount) * multiplier);
    const balanceResult = await client.query(
      `UPDATE players SET demo_coins = demo_coins + $1
       WHERE id = $2 RETURNING demo_coins::text AS demo_coins`,
      [payout, req.player.id],
    );
    await client.query(
      `UPDATE game_bets
       SET status = 'cashed_out', payout = $2, settled_at = NOW()
       WHERE id = $1`,
      [id, payout],
    );
    await client.query(
      `INSERT INTO coin_ledger (player_id, amount, entry_type, game_name)
       VALUES ($1, $2, 'game_payout', $3)`,
      [req.player.id, payout, bet.game_name],
    );
    await client.query("COMMIT");
    res.json({
      ok: true,
      payout,
      demoCoins: Number(balanceResult.rows[0].demo_coins),
    });
  } catch (error) {
    await client.query("ROLLBACK").catch(() => {});
    throw error;
  } finally {
    client.release();
  }
}));

app.post("/api/games/bets/:id/lose", requirePlayer, gameActionLimiter, asyncRoute(async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id) || id < 1) {
    return res.status(400).json({ error: "Invalid bet ID." });
  }
  const result = await pool.query(
    `UPDATE game_bets SET status = 'lost', settled_at = NOW()
     WHERE id = $1 AND player_id = $2 AND status = 'active'
     RETURNING id`,
    [id, req.player.id],
  );
  if (!result.rowCount) {
    return res.status(409).json({ error: "This bet has already been settled." });
  }
  res.json({ ok: true });
}));

async function getLuckyWheelPlayerSnapshot(queryable, playerId) {
  const [statsResult, recentResult] = await Promise.all([
    queryable.query(
      `SELECT
         COUNT(*)::int AS total_spins,
         COUNT(*) FILTER (WHERE reward > 0)::int AS total_wins,
         COUNT(*) FILTER (WHERE reward = 0)::int AS total_losses,
         COALESCE(SUM(reward - bet), 0)::text AS net_profit
       FROM lucky_wheel_spins
       WHERE player_id = $1`,
      [playerId],
    ),
    queryable.query(
      `SELECT bet::text AS bet, reward::text AS reward, result_label, created_at
       FROM lucky_wheel_spins
       WHERE player_id = $1
       ORDER BY id DESC
       LIMIT 8`,
      [playerId],
    ),
  ]);
  const stats = statsResult.rows[0];
  return {
    stats: {
      totalSpins: Number(stats.total_spins),
      totalWins: Number(stats.total_wins),
      totalLosses: Number(stats.total_losses),
      netProfit: Number(stats.net_profit),
    },
    recentResults: recentResult.rows.map((row) => ({
      stake: Number(row.bet),
      reward: Number(row.reward),
      resultLabel: row.result_label,
      createdAt: row.created_at.toISOString(),
    })),
  };
}

app.get("/api/games/lucky-wheel/state", requirePlayer, asyncRoute(async (req, res) => {
  const settingsResult = await pool.query(
    `SELECT win_chance_percent::text AS win_chance_percent
     FROM lucky_wheel_settings
     WHERE id = 1`,
  );
  const settings = settingsResult.rows[0];
  if (!settings) throw new Error("Lucky Wheel settings are not initialized.");
  const snapshot = await getLuckyWheelPlayerSnapshot(pool, req.player.id);
  res.set("Cache-Control", "no-store");
  res.json({
    demoCoins: Number(req.player.demo_coins),
    winChancePercent: Number(settings.win_chance_percent),
    ...snapshot,
  });
}));

app.post("/api/games/lucky-wheel/spin", requirePlayer, wheelSpinLimiter, asyncRoute(async (req, res) => {
  const bet = Number(req.body.bet);
  if (!Number.isSafeInteger(bet) || bet < 50 || bet > 1_000 || bet % 50 !== 0) {
    return res.status(400).json({
      error: "Enter a whole-number bet from 50 to 1,000 Demo Coins in steps of 50.",
    });
  }

  const winSegments = [
    { wheelIndex: 0, multiplier: 5, label: "5x" },
    { wheelIndex: 1, multiplier: 10, label: "10x" },
    { wheelIndex: 3, multiplier: 50, label: "50x" },
    { wheelIndex: 4, multiplier: 1, label: "1x" },
    { wheelIndex: 6, multiplier: 100, label: "100x" },
    { wheelIndex: 7, multiplier: 20, label: "20x" },
    { wheelIndex: 8, multiplier: 2, label: "2x" },
    { wheelIndex: 9, multiplier: 10, label: "10x" },
  ];
  const loseSegments = [2, 5];
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const playerResult = await client.query(
      "SELECT demo_coins::text AS demo_coins FROM players WHERE id = $1 FOR UPDATE",
      [req.player.id],
    );
    const currentBalance = Number(playerResult.rows[0]?.demo_coins);
    if (currentBalance < bet) {
      await client.query("ROLLBACK");
      return res.status(409).json({ error: "Not enough Demo Coins for this bet." });
    }

    const settingsResult = await client.query(
      `SELECT win_chance_percent::text AS win_chance_percent
       FROM lucky_wheel_settings
       WHERE id = 1
       FOR SHARE`,
    );
    const settings = settingsResult.rows[0];
    if (!settings) throw new Error("Lucky Wheel settings are not initialized.");
    const winChancePercent = Number(settings.win_chance_percent);
    const wins = crypto.randomInt(10_000) < Math.round(winChancePercent * 100);
    const outcome = wins
      ? winSegments[crypto.randomInt(winSegments.length)]
      : { wheelIndex: loseSegments[crypto.randomInt(loseSegments.length)], multiplier: 0, label: "PLAY AGAIN" };
    const reward = bet * outcome.multiplier;
    const netProfit = reward - bet;
    const balanceResult = await client.query(
      `UPDATE players
       SET demo_coins = demo_coins - $1 + $2
       WHERE id = $3
       RETURNING demo_coins::text AS demo_coins`,
      [bet, reward, req.player.id],
    );
    await client.query(
      `INSERT INTO coin_ledger (player_id, amount, entry_type, game_name)
       VALUES ($1, $2, 'game_stake', 'lucky-wheel')`,
      [req.player.id, bet],
    );
    if (reward) {
      await client.query(
        `INSERT INTO coin_ledger (player_id, amount, entry_type, game_name)
         VALUES ($1, $2, 'game_reward', 'lucky-wheel')`,
        [req.player.id, reward],
      );
    }
    await client.query(
      `INSERT INTO lucky_wheel_spins
         (player_id, bet, reward, result_label, wheel_index)
       VALUES ($1, $2, $3, $4, $5)`,
      [req.player.id, bet, reward, outcome.label, outcome.wheelIndex],
    );
    const snapshot = await getLuckyWheelPlayerSnapshot(client, req.player.id);
    await client.query("COMMIT");
    res.json({
      bet,
      reward,
      resultLabel: outcome.label,
      wheelIndex: outcome.wheelIndex,
      winChancePercent,
      netProfit,
      demoCoins: Number(balanceResult.rows[0].demo_coins),
      ...snapshot,
    });
  } catch (error) {
    await client.query("ROLLBACK").catch(() => {});
    throw error;
  } finally {
    client.release();
  }
}));

app.get("/api/games/dragon-tiger/state", requirePlayer, asyncRoute(async (req, res) => {
  res.set("Cache-Control", "no-store");
  res.json(await getDragonTigerState(pool, req.player.id));
}));

app.post("/api/games/dragon-tiger/bets", requirePlayer, gameActionLimiter, asyncRoute(async (req, res) => {
  const pick = cleanText(req.body.pick, 8);
  const amount = Number(req.body.amount);
  const result = await placeDragonTigerBet(pool, req.player.id, pick, amount);
  if (result.error) {
    return res.status(result.status).json({ error: result.error });
  }
  res.status(result.status).json(result);
}));

app.get("/api/admin/session", (req, res) => {
  res.set("Cache-Control", "no-store");
  res.json({ authenticated: req.session.isAdmin === true });
});

app.post("/api/admin/login", adminLoginLimiter, asyncRoute(async (req, res) => {
  if (!ADMIN_PASSWORD) {
    return res.status(503).json({ error: "Admin login is not configured. Add ADMIN_PASSWORD in Replit Secrets." });
  }
  const password = typeof req.body.password === "string" ? req.body.password : "";
  if (!safeSecretCompare(password, ADMIN_PASSWORD)) {
    return res.status(401).json({ error: "Admin password is incorrect." });
  }
  await regenerateSession(req);
  req.session.isAdmin = true;
  req.session.cookie.maxAge = 6 * 60 * 60 * 1000;
  await saveSession(req);
  res.json({ authenticated: true });
}));

app.post("/api/admin/logout", requireAdmin, asyncRoute(async (req, res) => {
  await destroySession(req);
  clearSessionCookie(req, res);
  res.json({ ok: true });
}));

app.get("/api/admin/games/stats", requireAdmin, asyncRoute(async (_req, res) => {
  const dayStart = `(date_trunc('day', NOW() AT TIME ZONE 'Asia/Karachi')
    AT TIME ZONE 'Asia/Karachi')`;
  const [gameBetsResult, dragonTigerBetsResult, dragonTigerRoundsResult] = await Promise.all([
    pool.query(
      `WITH day_window AS (SELECT ${dayStart} AS starts_at)
       SELECT game_name,
              COUNT(*) FILTER (WHERE created_at >= day_window.starts_at)::int AS today_bets,
              COUNT(*) FILTER (WHERE status = 'active')::int AS active_bets,
              COUNT(*) FILTER (
                WHERE status = 'cashed_out' AND settled_at >= day_window.starts_at
              )::int AS today_wins,
              COUNT(*) FILTER (
                WHERE status = 'lost' AND settled_at >= day_window.starts_at
              )::int AS today_losses,
              COALESCE(SUM(amount) FILTER (
                WHERE created_at >= day_window.starts_at
              ), 0)::text AS today_wagered,
              COALESCE(SUM(payout) FILTER (
                WHERE settled_at >= day_window.starts_at
              ), 0)::text AS today_paid_out
        FROM game_bets, day_window
        WHERE game_name IN ('aviator', 'crash')
          AND (created_at >= day_window.starts_at OR status = 'active')
        GROUP BY game_name`,
    ),
    pool.query(
      `WITH day_window AS (SELECT ${dayStart} AS starts_at)
       SELECT COUNT(*) FILTER (
                WHERE dragon_tiger_bets.created_at >= day_window.starts_at
              )::int AS today_bets,
              COUNT(*) FILTER (WHERE status = 'active')::int AS active_bets,
              COUNT(*) FILTER (
                WHERE status = 'won' AND settled_at >= day_window.starts_at
              )::int AS today_wins,
              COUNT(*) FILTER (
                WHERE status = 'lost' AND settled_at >= day_window.starts_at
              )::int AS today_losses,
              COUNT(*) FILTER (
                WHERE status = 'push' AND settled_at >= day_window.starts_at
              )::int AS today_pushes,
              COALESCE(SUM(amount) FILTER (
                WHERE dragon_tiger_bets.created_at >= day_window.starts_at
              ), 0)::text AS today_wagered,
              COALESCE(SUM(payout) FILTER (
                WHERE settled_at >= day_window.starts_at
              ), 0)::text AS today_paid_out
        FROM dragon_tiger_bets, day_window
        WHERE dragon_tiger_bets.created_at >= day_window.starts_at
           OR status = 'active'`,
    ),
    pool.query(
      `SELECT COUNT(*)::int AS today_rounds
       FROM dragon_tiger_rounds
       WHERE created_at >= ${dayStart}`,
    ),
  ]);
  const games = Object.fromEntries(gameBetsResult.rows.map((row) => [
    row.game_name,
    {
      todayBets: Number(row.today_bets),
      activeBets: Number(row.active_bets),
      todayWins: Number(row.today_wins),
      todayLosses: Number(row.today_losses),
      todayWagered: Number(row.today_wagered),
      todayPaidOut: Number(row.today_paid_out),
    },
  ]));
  const dragonTiger = dragonTigerBetsResult.rows[0];
  res.set("Cache-Control", "no-store");
  res.json({
    games,
    dragonTiger: {
      todayRounds: Number(dragonTigerRoundsResult.rows[0].today_rounds),
      todayBets: Number(dragonTiger.today_bets),
      activeBets: Number(dragonTiger.active_bets),
      todayWins: Number(dragonTiger.today_wins),
      todayLosses: Number(dragonTiger.today_losses),
      todayPushes: Number(dragonTiger.today_pushes),
      todayWagered: Number(dragonTiger.today_wagered),
      todayPaidOut: Number(dragonTiger.today_paid_out),
    },
  });
}));

app.get("/api/admin/lucky-wheel", requireAdmin, asyncRoute(async (_req, res) => {
  const [settingsResult, statsResult] = await Promise.all([
    pool.query(
      `SELECT win_chance_percent::text AS win_chance_percent, updated_at
       FROM lucky_wheel_settings
       WHERE id = 1`,
    ),
    pool.query(
      `SELECT
         COUNT(*)::int AS total_spins,
         COUNT(*) FILTER (WHERE reward > 0)::int AS total_wins,
         COUNT(*) FILTER (WHERE reward = 0)::int AS total_losses,
         COALESCE(SUM(bet), 0)::text AS total_staked,
         COALESCE(SUM(reward), 0)::text AS total_awarded,
         COALESCE(SUM(reward - bet), 0)::text AS net_profit
       FROM lucky_wheel_spins
       WHERE created_at >= (
         date_trunc('day', NOW() AT TIME ZONE 'Asia/Karachi')
         AT TIME ZONE 'Asia/Karachi'
       )`,
    ),
  ]);
  const settings = settingsResult.rows[0];
  if (!settings) throw new Error("Lucky Wheel settings are not initialized.");
  const stats = statsResult.rows[0];
  res.set("Cache-Control", "no-store");
  res.json({
    winChancePercent: Number(settings.win_chance_percent),
    updatedAt: settings.updated_at,
    today: {
      totalSpins: Number(stats.total_spins),
      totalWins: Number(stats.total_wins),
      totalLosses: Number(stats.total_losses),
      totalStaked: Number(stats.total_staked),
      totalAwarded: Number(stats.total_awarded),
      netProfit: Number(stats.net_profit),
    },
  });
}));

app.patch("/api/admin/lucky-wheel/settings", requireAdmin, asyncRoute(async (req, res) => {
  const winChancePercent = Number(req.body.winChancePercent);
  if (
    !Number.isFinite(winChancePercent) ||
    winChancePercent < 1 ||
    winChancePercent > 100 ||
    !Number.isInteger(winChancePercent)
  ) {
    return res.status(400).json({
      error: "Set the win chance from 1% to 100% in whole-number steps.",
    });
  }
  const result = await pool.query(
    `UPDATE lucky_wheel_settings
     SET win_chance_percent = $1, updated_at = NOW()
     WHERE id = 1
     RETURNING win_chance_percent::text AS win_chance_percent, updated_at`,
    [winChancePercent],
  );
  if (!result.rows[0]) throw new Error("Lucky Wheel settings are not initialized.");
  res.set("Cache-Control", "no-store");
  res.json({
    winChancePercent: Number(result.rows[0].win_chance_percent),
    updatedAt: result.rows[0].updated_at,
  });
}));

app.get("/api/admin/summary", requireAdmin, asyncRoute(async (_req, res) => {
  const result = await pool.query(
    `SELECT
       (SELECT COUNT(*) FILTER (WHERE status = 'pending')::int FROM deposit_requests) AS deposit_pending,
       (SELECT COUNT(*) FILTER (WHERE status = 'accepted')::int FROM deposit_requests) AS deposit_accepted,
       (SELECT COUNT(*) FILTER (WHERE status = 'rejected')::int FROM deposit_requests) AS deposit_rejected,
       (SELECT COUNT(*) FILTER (WHERE status = 'pending')::int FROM withdrawal_requests) AS withdrawal_pending,
       (SELECT COUNT(*) FILTER (WHERE status = 'accepted')::int FROM withdrawal_requests) AS withdrawal_accepted,
       (SELECT COUNT(*) FILTER (WHERE status = 'rejected')::int FROM withdrawal_requests) AS withdrawal_rejected,
       (SELECT COUNT(*)::int FROM players) AS players
     `,
  );
  res.set("Cache-Control", "no-store");
  res.json(result.rows[0]);
}));

app.get("/api/admin/deposit-requests", requireAdmin, asyncRoute(async (req, res) => {
  const status = cleanText(req.query.status, 16) || "pending";

  if (!["pending", "accepted", "rejected", "all"].includes(status)) {
    return res.status(400).json({
      error: "Unknown request filter."
    });
  }

  const params = status === "all" ? [] : [status];
  const where = status === "all" ? "" : "WHERE dr.status = $1";

  const result = await pool.query(
    `SELECT
       dr.id,
       dr.amount::text AS amount,
       dr.note,
       dr.sender_name,
       dr.sender_number,
       dr.trx_id,
       dr.status,
       dr.created_at,
       dr.reviewed_at,
       dr.admin_note,
       p.id AS player_id,
       p.full_name,
       p.email,
       p.phone
     FROM deposit_requests dr
     JOIN players p ON p.id = dr.player_id
     ${where}
     ORDER BY
       CASE WHEN dr.status = 'pending' THEN 0 ELSE 1 END,
       dr.created_at DESC
     LIMIT 250`,
    params,
  );

  res.set("Cache-Control", "no-store");

  res.json({
    requests: result.rows.map((row) => ({
      id: Number(row.id),
      amount: Number(row.amount),
      note: row.note,

      senderName: row.sender_name,
      senderNumber: row.sender_number,
      trxId: row.trx_id,

      status: row.status,
      createdAt: row.created_at,
      reviewedAt: row.reviewed_at,
      adminNote: row.admin_note,

      player: {
        id: Number(row.player_id),
        fullName: row.full_name,
        email: row.email,
        phone: row.phone,
      },
    })),
  });
}));
app.get("/api/admin/withdrawal-requests", requireAdmin, asyncRoute(async (req, res) => {
  const status = cleanText(req.query.status, 16) || "pending";
  if (!["pending", "accepted", "rejected", "all"].includes(status)) {
    return res.status(400).json({ error: "Unknown request filter." });
  }
  const params = status === "all" ? [] : [status];
  const where = status === "all" ? "" : "WHERE wr.status = $1";
  const result = await pool.query(
    `SELECT wr.id, wr.provider, wr.account_phone, wr.amount::text AS amount,
            wr.status, wr.created_at, wr.reviewed_at, wr.admin_note,
            p.id AS player_id, p.full_name, p.email, p.phone
     FROM withdrawal_requests wr
     JOIN players p ON p.id = wr.player_id
     ${where}
     ORDER BY CASE WHEN wr.status = 'pending' THEN 0 ELSE 1 END, wr.created_at DESC
     LIMIT 250`,
    params,
  );
  res.set("Cache-Control", "no-store");
  res.json({
    requests: result.rows.map((row) => ({
      id: Number(row.id),
      provider: row.provider,
      accountPhone: row.account_phone,
      amount: Number(row.amount),
      status: row.status,
      createdAt: row.created_at,
      reviewedAt: row.reviewed_at,
      adminNote: row.admin_note,
      player: {
        id: Number(row.player_id),
        fullName: row.full_name,
        email: row.email,
        phone: row.phone,
      },
    })),
  });
}));

app.post("/api/admin/deposit-requests/:id/accept", requireAdmin, asyncRoute(async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id) || id < 1) {
    return res.status(400).json({ error: "Invalid request ID." });
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const requestResult = await client.query(
      "SELECT id, player_id, amount, status FROM deposit_requests WHERE id = $1 FOR UPDATE",
      [id],
    );
    const deposit = requestResult.rows[0];
    if (!deposit) {
      await client.query("ROLLBACK");
      return res.status(404).json({ error: "Request not found." });
    }
    if (deposit.status !== "pending") {
      await client.query("ROLLBACK");
      return res.status(409).json({ error: "This request has already been reviewed." });
    }

    const balanceResult = await client.query(
      `UPDATE players SET demo_coins = demo_coins + $1
       WHERE id = $2
       RETURNING demo_coins::text AS demo_coins`,
      [deposit.amount, deposit.player_id],
    );
    await client.query(
      `INSERT INTO coin_ledger (player_id, amount, entry_type, deposit_request_id)
       VALUES ($1, $2, 'deposit_accepted', $3)`,
      [deposit.player_id, deposit.amount, id],
    );
    await client.query(
      `UPDATE deposit_requests
       SET status = 'accepted', reviewed_at = NOW(), reviewed_by = 'admin'
       WHERE id = $1`,
      [id],
    );
    await client.query("COMMIT");
    res.json({ ok: true, demoCoins: Number(balanceResult.rows[0].demo_coins) });
  } catch (error) {
    await client.query("ROLLBACK").catch(() => {});
    throw error;
  } finally {
    client.release();
  }
}));

app.post("/api/admin/deposit-requests/:id/reject", requireAdmin, asyncRoute(async (req, res) => {
  const id = Number(req.params.id);
  const adminNote = cleanText(req.body.adminNote, 240);
  if (!Number.isSafeInteger(id) || id < 1) {
    return res.status(400).json({ error: "Invalid request ID." });
  }
  const result = await pool.query(
    `UPDATE deposit_requests
     SET status = 'rejected', reviewed_at = NOW(), reviewed_by = 'admin', admin_note = $2
     WHERE id = $1 AND status = 'pending'
     RETURNING id`,
    [id, adminNote],
  );
  if (!result.rowCount) {
    const exists = await pool.query("SELECT status FROM deposit_requests WHERE id = $1", [id]);
    if (!exists.rowCount) return res.status(404).json({ error: "Request not found." });
    return res.status(409).json({ error: "This request has already been reviewed." });
  }
  res.json({ ok: true });
}));

app.post("/api/admin/withdrawal-requests/:id/accept", requireAdmin, asyncRoute(async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id) || id < 1) {
    return res.status(400).json({ error: "Invalid request ID." });
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const requestResult = await client.query(
      "SELECT id, status FROM withdrawal_requests WHERE id = $1 FOR UPDATE",
      [id],
    );
    const request = requestResult.rows[0];
    if (!request) {
      await client.query("ROLLBACK");
      return res.status(404).json({ error: "Request not found." });
    }
    if (request.status !== "pending") {
      await client.query("ROLLBACK");
      return res.status(409).json({ error: "This request has already been reviewed." });
    }

    await client.query(
      `UPDATE withdrawal_requests
       SET status = 'accepted', reviewed_at = NOW(), reviewed_by = 'admin',
           admin_note = $2
       WHERE id = $1`,
      [id, cleanText(req.body.adminNote, 240)],
    );
    await client.query(
      `UPDATE coin_ledger
       SET entry_type = 'withdrawal_accepted'
       WHERE withdrawal_request_id = $1 AND entry_type = 'withdrawal_requested'`,
      [id],
    );
    await client.query("COMMIT");
    res.json({ ok: true });
  } catch (error) {
    await client.query("ROLLBACK").catch(() => {});
    throw error;
  } finally {
    client.release();
  }
}));

app.post("/api/admin/withdrawal-requests/:id/reject", requireAdmin, asyncRoute(async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id) || id < 1) {
    return res.status(400).json({ error: "Invalid request ID." });
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const requestResult = await client.query(
      `SELECT id, player_id, amount, provider, status
       FROM withdrawal_requests WHERE id = $1 FOR UPDATE`,
      [id],
    );
    const request = requestResult.rows[0];
    if (!request) {
      await client.query("ROLLBACK");
      return res.status(404).json({ error: "Request not found." });
    }
    if (request.status !== "pending") {
      await client.query("ROLLBACK");
      return res.status(409).json({ error: "This request has already been reviewed." });
    }

    const balanceResult = await client.query(
      `UPDATE players SET demo_coins = demo_coins + $1
       WHERE id = $2 RETURNING demo_coins::text AS demo_coins`,
      [request.amount, request.player_id],
    );
    await client.query(
      `UPDATE withdrawal_requests
       SET status = 'rejected', reviewed_at = NOW(), reviewed_by = 'admin',
           admin_note = $2
       WHERE id = $1`,
      [id, cleanText(req.body.adminNote, 240)],
    );
    await client.query(
      `UPDATE coin_ledger
       SET entry_type = 'withdrawal_rejected'
       WHERE withdrawal_request_id = $1 AND entry_type = 'withdrawal_requested'`,
      [id],
    );
    await client.query(
      `INSERT INTO coin_ledger (player_id, amount, entry_type, withdrawal_request_id)
       VALUES ($1, $2, 'withdrawal_refund', $3)`,
      [request.player_id, request.amount, id],
    );
    await client.query("COMMIT");
    res.json({ ok: true, demoCoins: Number(balanceResult.rows[0].demo_coins) });
  } catch (error) {
    await client.query("ROLLBACK").catch(() => {});
    throw error;
  } finally {
    client.release();
  }
}));

app.get("/nimda312", (_req, res) => {
  res.set("Cache-Control", "no-store");
  res.sendFile(path.join(ROOT, "private", "admin.html"));
});
app.get("/nimda312/", (_req, res) => res.redirect(301, ADMIN_PATH));

app.get(["/", "/index.html"], (_req, res) => {
  res.sendFile(path.join(ROOT, "index.html"));
});
app.use("/public", express.static(path.join(ROOT, "public"), { maxAge: 0 }));
app.use("/pages", express.static(path.join(ROOT, "pages"), { maxAge: 0 }));
app.use("/api", (_req, res) => res.status(404).json({ error: "API route not found." }));
app.use((_req, res) => res.status(404).type("text/plain").send("404 — File not found"));

app.use((error, _req, res, _next) => {
  console.error("Request failed:", error.code || error.name || "SERVER_ERROR");
  if (res.headersSent) return;
  const status = Number.isInteger(error.status) && error.status >= 400 && error.status < 500
    ? error.status
    : 500;
  res.status(status).json({
    error: status === 413
      ? "Request is too large."
      : status < 500
        ? "Invalid request."
        : "A server error occurred. Please try again.",
  });
});

pool.query("SELECT 1")
  .then(() => {
    startDragonTigerRounds(pool);
    const server = app.listen(PORT, "0.0.0.0", () => {
      console.log(`S999 server listening on port ${PORT}`);
    });
    const shutdown = () => {
      server.close(() => pool.end().finally(() => process.exit(0)));
    };
    process.on("SIGTERM", shutdown);
    process.on("SIGINT", shutdown);
  })
  .catch((error) => {
    console.error("S999 database connection failed:", error.code || "DATABASE_CONNECTION_ERROR");
    process.exit(1);
  });
