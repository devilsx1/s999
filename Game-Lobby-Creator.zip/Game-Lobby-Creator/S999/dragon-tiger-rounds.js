const crypto = require("node:crypto");

const LOCK_NAMESPACE = 999312;
const LOCK_ID = 1;
const BETTING_WINDOW_SECONDS = 12;
const RESULT_HOLD_SECONDS = 3;
const MIN_BET = 20;
const MAX_BET = 20_000;
const TIE_TOTAL_RETURN_MULTIPLIER = 9;

const ranks = [
  { rank: "2", value: 2 },
  { rank: "3", value: 3 },
  { rank: "4", value: 4 },
  { rank: "5", value: 5 },
  { rank: "6", value: 6 },
  { rank: "7", value: 7 },
  { rank: "8", value: 8 },
  { rank: "9", value: 9 },
  { rank: "10", value: 10 },
  { rank: "J", value: 11 },
  { rank: "Q", value: 12 },
  { rank: "K", value: 13 },
  { rank: "A", value: 14 },
];
const suits = ["♠", "♥", "♦", "♣"];

let engineTimer;

function iso(value) {
  return value ? new Date(value).toISOString() : null;
}

function roundCard(row, side) {
  if (!row[`${side}_rank`] || !row[`${side}_suit`]) return null;
  return {
    rank: row[`${side}_rank`],
    suit: row[`${side}_suit`],
  };
}

function publicRound(row) {
  if (!row) return null;
  const settled = row.status === "settled";
  const settledAt = iso(row.settled_at);

  return {
    id: String(row.id),
    status: row.status,
    createdAt: iso(row.created_at),
    bettingEndsAt: iso(row.betting_ends_at),
    revealAt: iso(row.reveal_at),
    settledAt,
    nextRoundAt: settledAt
      ? new Date(new Date(settledAt).getTime() + RESULT_HOLD_SECONDS * 1000).toISOString()
      : null,
    dragon: settled ? roundCard(row, "dragon") : null,
    tiger: settled ? roundCard(row, "tiger") : null,
    winner: settled ? row.winner : null,
  };
}

function calculateBetSettlement(pick, winner, amount) {
  if (winner === "tie") {
    return pick === "tie"
      ? { status: "won", payout: amount * TIE_TOTAL_RETURN_MULTIPLIER }
      : { status: "push", payout: amount };
  }

  return pick === winner
    ? { status: "won", payout: amount * 2 }
    : { status: "lost", payout: 0 };
}

function isValidBetAmount(amount) {
  return (
    Number.isSafeInteger(amount) &&
    amount >= MIN_BET &&
    amount <= MAX_BET
  );
}

function shuffleDeck() {
  const deck = suits.flatMap((suit) =>
    ranks.map((card) => ({ ...card, suit })),
  );

  for (let index = deck.length - 1; index > 0; index -= 1) {
    const swapIndex = crypto.randomInt(index + 1);
    [deck[index], deck[swapIndex]] = [deck[swapIndex], deck[index]];
  }

  return deck;
}

async function createRound(client) {
  await client.query(
    `INSERT INTO dragon_tiger_rounds
       (status, created_at, betting_ends_at, reveal_at)
     VALUES (
       'betting',
       NOW(),
       NOW() + ($1 * INTERVAL '1 second'),
        NOW() + ($1 * INTERVAL '1 second')
     )`,
    [BETTING_WINDOW_SECONDS],
  );
}

async function settleRound(client, round) {
  const [dragon, tiger] = shuffleDeck();
  const winner = dragon.value === tiger.value
    ? "tie"
    : dragon.value > tiger.value
      ? "dragon"
      : "tiger";

  const bets = await client.query(
    `SELECT id::text AS id, player_id, pick, amount::text AS amount
     FROM dragon_tiger_bets
     WHERE round_id = $1 AND status = 'active'
     ORDER BY player_id
     FOR UPDATE`,
    [round.id],
  );

  for (const bet of bets.rows) {
    const amount = Number(bet.amount);
    const { status, payout } = calculateBetSettlement(bet.pick, winner, amount);

    if (payout > 0) {
      await client.query(
        `UPDATE players
         SET demo_coins = demo_coins + $1
         WHERE id = $2`,
        [payout, bet.player_id],
      );
      await client.query(
        `INSERT INTO coin_ledger (player_id, amount, entry_type, game_name)
         VALUES ($1, $2, 'game_payout', 'dragon-tiger')`,
        [bet.player_id, payout],
      );
    }

    await client.query(
      `UPDATE dragon_tiger_bets
       SET status = $1, payout = $2, settled_at = NOW()
       WHERE id = $3`,
      [status, payout, bet.id],
    );
  }

  await client.query(
    `UPDATE dragon_tiger_rounds
     SET status = 'settled',
         dragon_rank = $1,
         dragon_suit = $2,
         tiger_rank = $3,
         tiger_suit = $4,
         winner = $5,
         settled_at = NOW()
     WHERE id = $6`,
    [dragon.rank, dragon.suit, tiger.rank, tiger.suit, winner, round.id],
  );
}

async function advanceRound(pool) {
  const client = await pool.connect();

  try {
    await client.query("BEGIN");
    const lock = await client.query(
      "SELECT pg_try_advisory_xact_lock($1, $2) AS acquired",
      [LOCK_NAMESPACE, LOCK_ID],
    );
    if (!lock.rows[0]?.acquired) {
      await client.query("ROLLBACK");
      return;
    }

    const result = await client.query(
      `SELECT id::text AS id, status, betting_ends_at, reveal_at, settled_at
       FROM dragon_tiger_rounds
       ORDER BY dragon_tiger_rounds.id DESC
       LIMIT 1
       FOR UPDATE`,
    );
    const round = result.rows[0];

    if (!round) {
      await createRound(client);
      await client.query("COMMIT");
      return;
    }

    const nowResult = await client.query("SELECT NOW() AS now");
    const now = new Date(nowResult.rows[0].now).getTime();

    if (
      round.status === "betting" &&
      now >= new Date(round.betting_ends_at).getTime()
    ) {
      await settleRound(client, round);
    } else if (
      round.status === "revealing" &&
      now >= new Date(round.reveal_at).getTime()
    ) {
      await settleRound(client, round);
    } else if (
      round.status === "settled" &&
      round.settled_at &&
      now >= new Date(round.settled_at).getTime() + RESULT_HOLD_SECONDS * 1000
    ) {
      await createRound(client);
    }

    await client.query("COMMIT");
  } catch (error) {
    await client.query("ROLLBACK").catch(() => {});
    throw error;
  } finally {
    client.release();
  }
}

function startDragonTigerRounds(pool) {
  if (engineTimer) return engineTimer;

  let ticking = false;
  const tick = async () => {
    if (ticking) return;
    ticking = true;
    try {
      await advanceRound(pool);
    } catch (error) {
      console.error(
        "Dragon Tiger round engine error:",
        error.code || "ROUND_ENGINE_ERROR",
      );
    } finally {
      ticking = false;
    }
  };

  void tick();
  engineTimer = setInterval(tick, 500);
  return engineTimer;
}

async function getDragonTigerState(pool, playerId) {
  const result = await pool.query(
    `SELECT NOW() AS server_time,
            p.demo_coins::text AS demo_coins,
            current_round.id::text AS current_round_id,
            current_round.status AS current_status,
            current_round.created_at AS current_created_at,
            current_round.betting_ends_at AS current_betting_ends_at,
            current_round.reveal_at AS current_reveal_at,
            current_round.settled_at AS current_settled_at,
            current_round.dragon_rank AS current_dragon_rank,
            current_round.dragon_suit AS current_dragon_suit,
            current_round.tiger_rank AS current_tiger_rank,
            current_round.tiger_suit AS current_tiger_suit,
            current_round.winner AS current_winner,
            current_bet.id::text AS bet_id,
            current_bet.pick AS bet_pick,
            current_bet.amount::text AS bet_amount,
            current_bet.status AS bet_status,
            current_bet.payout::text AS bet_payout,
            COALESCE((
              SELECT jsonb_agg(
                jsonb_build_object(
                  'id', history.id::text,
                  'status', history.status,
                  'created_at', history.created_at,
                  'betting_ends_at', history.betting_ends_at,
                  'reveal_at', history.reveal_at,
                  'settled_at', history.settled_at,
                  'dragon_rank', history.dragon_rank,
                  'dragon_suit', history.dragon_suit,
                  'tiger_rank', history.tiger_rank,
                  'tiger_suit', history.tiger_suit,
                  'winner', history.winner
                )
                ORDER BY history.id DESC
              )
              FROM (
                SELECT id, status, created_at, betting_ends_at, reveal_at,
                       settled_at, dragon_rank, dragon_suit, tiger_rank,
                       tiger_suit, winner
                FROM dragon_tiger_rounds
                WHERE status = 'settled'
                ORDER BY id DESC
                LIMIT 12
              ) history
            ), '[]'::jsonb) AS recent_rounds
     FROM players p
     LEFT JOIN LATERAL (
       SELECT id, status, created_at, betting_ends_at, reveal_at, settled_at,
              dragon_rank, dragon_suit, tiger_rank, tiger_suit, winner
       FROM dragon_tiger_rounds
       ORDER BY id DESC
       LIMIT 1
     ) current_round ON TRUE
     LEFT JOIN LATERAL (
       SELECT id, pick, amount, status, payout
       FROM dragon_tiger_bets
       WHERE round_id = current_round.id AND player_id = p.id
       LIMIT 1
     ) current_bet ON TRUE
     WHERE p.id = $1`,
    [playerId],
  );

  const row = result.rows[0];
  const current = row?.current_round_id
    ? {
        id: row.current_round_id,
        status: row.current_status,
        created_at: row.current_created_at,
        betting_ends_at: row.current_betting_ends_at,
        reveal_at: row.current_reveal_at,
        settled_at: row.current_settled_at,
        dragon_rank: row.current_dragon_rank,
        dragon_suit: row.current_dragon_suit,
        tiger_rank: row.current_tiger_rank,
        tiger_suit: row.current_tiger_suit,
        winner: row.current_winner,
      }
    : null;

  return {
    serverTime: iso(row?.server_time),
    demoCoins: Number(row?.demo_coins || 0),
    currentRound: publicRound(current),
    myBet: row?.bet_id
      ? {
          id: String(row.bet_id),
          pick: row.bet_pick,
          amount: Number(row.bet_amount),
          status: row.bet_status,
          payout: Number(row.bet_payout),
        }
      : null,
    recentRounds: (row?.recent_rounds || []).map(publicRound),
  };
}

async function placeDragonTigerBet(pool, playerId, pick, amount) {
  if (!["dragon", "tiger", "tie"].includes(pick)) {
    return { status: 400, error: "Choose Dragon, Tiger, or Tie." };
  }
  if (!isValidBetAmount(amount)) {
    return {
      status: 400,
      error: `Enter a whole-number bet from ${MIN_BET} to ${MAX_BET.toLocaleString()} Demo Coins.`,
    };
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query(
      "SELECT pg_advisory_xact_lock($1, $2)",
      [LOCK_NAMESPACE, LOCK_ID],
    );

    const roundResult = await client.query(
      `SELECT id::text AS id, status, betting_ends_at > NOW() AS bet_open
       FROM dragon_tiger_rounds
       ORDER BY dragon_tiger_rounds.id DESC
       LIMIT 1
       FOR UPDATE`,
    );
    const round = roundResult.rows[0];
    if (!round || round.status !== "betting" || !round.bet_open) {
      await client.query("ROLLBACK");
      return { status: 409, error: "This round is closed. Wait for the next round." };
    }

    const existingBet = await client.query(
      `SELECT id FROM dragon_tiger_bets
       WHERE round_id = $1 AND player_id = $2`,
      [round.id, playerId],
    );
    if (existingBet.rowCount) {
      await client.query("ROLLBACK");
      return { status: 409, error: "You already placed a bet in this round." };
    }

    const playerResult = await client.query(
      "SELECT demo_coins::text AS demo_coins FROM players WHERE id = $1 FOR UPDATE",
      [playerId],
    );
    const balance = Number(playerResult.rows[0]?.demo_coins || 0);
    if (amount > balance) {
      await client.query("ROLLBACK");
      return { status: 409, error: "Not enough Demo Coins." };
    }

    const betResult = await client.query(
      `INSERT INTO dragon_tiger_bets (round_id, player_id, pick, amount)
       VALUES ($1, $2, $3, $4)
       RETURNING id::text AS id`,
      [round.id, playerId, pick, amount],
    );
    const updatedBalance = await client.query(
      `UPDATE players
       SET demo_coins = demo_coins - $1
       WHERE id = $2
       RETURNING demo_coins::text AS demo_coins`,
      [amount, playerId],
    );
    await client.query(
      `INSERT INTO coin_ledger (player_id, amount, entry_type, game_name)
       VALUES ($1, $2, 'game_stake', 'dragon-tiger')`,
      [playerId, amount],
    );
    await client.query("COMMIT");

    return {
      status: 201,
      bet: {
        id: String(betResult.rows[0].id),
        roundId: String(round.id),
        pick,
        amount,
        status: "active",
      },
      demoCoins: Number(updatedBalance.rows[0].demo_coins),
    };
  } catch (error) {
    await client.query("ROLLBACK").catch(() => {});
    if (error.code === "23505") {
      return { status: 409, error: "You already placed a bet in this round." };
    }
    throw error;
  } finally {
    client.release();
  }
}

module.exports = {
  calculateBetSettlement,
  getDragonTigerState,
  isValidBetAmount,
  placeDragonTigerBet,
  startDragonTigerRounds,
};
