const $ = id => document.getElementById(id);
function spinSlots(){let s=['🍒','🔔','7️⃣','🍋','💎','🍇'];let a=Array.from({length:3},()=>s[Math.floor(Math.random()*s.length)]);$('reels').textContent=a.join(' ');$('gameStatus').textContent=a.every(x=>x===a[0])?'Match! Nice spin result.':'Reels stopped.';}
