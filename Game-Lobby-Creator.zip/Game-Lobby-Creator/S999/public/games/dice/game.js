const $ = id => document.getElementById(id);
function rollDice(){let a=1+Math.floor(Math.random()*6),b=1+Math.floor(Math.random()*6);$('dice').textContent=['⚀','⚁','⚂','⚃','⚄','⚅'][a-1]+' '+['⚀','⚁','⚂','⚃','⚄','⚅'][b-1];$('gameStatus').textContent='Total: '+(a+b);}
