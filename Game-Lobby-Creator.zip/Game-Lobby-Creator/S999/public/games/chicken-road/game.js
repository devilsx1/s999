const $ = id => document.getElementById(id);
let steps=0; function chickenStep(){steps++;$('chicken').textContent='🐔 '+Array.from({length:Math.min(steps,3)},()=>Math.random()>.25?'🟩':'🟥').join(' ');$('gameStatus').textContent=Math.random()>.25?'Safe tile! Keep playing.':'Round over — try again.';if(steps>=3)steps=0;}
