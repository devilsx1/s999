(() => {
  const $ = id => document.getElementById(id);
  const betInput = $("betAmount");
  const rotor = $("wheelRotor");
  const status = $("gameStatus");
  const mainSpinButton = $("spinButton");
  const centerSpinButton = $("wheelCenter");
  const payoutPreview = $("maxPayout");
  const betButtons = [...document.querySelectorAll("[data-bet]")];
  const betOptions = [50, 100, 200, 500, 1000];
  let selectedBet = 500;
  let currentRotation = 0;
  let isSpinning = false;

  function formatCoins(value) {
    return Number(value || 0).toLocaleString();
  }

  function formatChance(value) {
    return Number(value).toLocaleString(undefined, {maximumFractionDigits: 1});
  }

  function setStatus(message, outcome = "") {
    status.textContent = message;
    if (outcome) status.dataset.outcome = outcome;
    else delete status.dataset.outcome;
  }

  function setBet(value) {
    const nextBet = Math.max(50, Math.min(1000, Math.round(Number(value) / 50) * 50));
    if (!Number.isFinite(nextBet)) return;
    selectedBet = nextBet;
    betInput.value = String(nextBet);
    $("spinStake").textContent = `${formatCoins(nextBet)} COINS`;
    payoutPreview.textContent = formatCoins(nextBet * 100);
    betButtons.forEach(button => {
      button.classList.toggle("is-selected", Number(button.dataset.bet) === nextBet);
    });
    updateSpinAvailability();
  }

  function updateSpinAvailability() {
    const canAfford = Number(coins) >= selectedBet;
    const disabled = isSpinning || !canAfford;
    mainSpinButton.disabled = disabled;
    centerSpinButton.disabled = disabled;
    mainSpinButton.setAttribute("aria-disabled", String(disabled));
    $("decreaseBet").disabled = isSpinning || selectedBet <= 50;
    $("increaseBet").disabled = isSpinning || selectedBet >= 1000;
    betInput.disabled = isSpinning;
    betButtons.forEach(button => { button.disabled = isSpinning; });
    if (!isSpinning && !canAfford) {
      setStatus("Not enough Demo Coins for this bet.");
    }
  }

  function renderStats(stats = {}) {
    $("totalSpins").textContent = formatCoins(stats.totalSpins);
    $("totalWins").textContent = formatCoins(stats.totalWins);
    $("totalLosses").textContent = formatCoins(stats.totalLosses);
    const netProfit = Number(stats.netProfit || 0);
    const profit = $("netProfit");
    profit.textContent = `${netProfit > 0 ? "+" : ""}${formatCoins(netProfit)}`;
    profit.classList.toggle("positive", netProfit > 0);
    profit.classList.toggle("negative", netProfit < 0);
  }

  function renderRecent(results = []) {
    const container = $("recentResults");
    container.replaceChildren();
    const visible = results.slice(0, 8);
    if (!visible.length) {
      const empty = document.createElement("span");
      empty.className = "recent-empty";
      empty.textContent = "Spin results will appear here";
      container.append(empty);
      return;
    }

    visible.forEach(result => {
      const chip = document.createElement("div");
      const won = Number(result.reward) > 0;
      chip.className = `result-chip ${won ? "is-win" : "is-loss"}`;
      const outcome = document.createElement("b");
      outcome.textContent = result.resultLabel || (won ? "WIN" : "LOSE");
      const amount = document.createElement("small");
      amount.textContent = won ? `+${formatCoins(result.reward)}` : `−${formatCoins(result.stake)}`;
      chip.append(outcome, amount);
      container.append(chip);
    });
  }

  async function parseResponse(response) {
    let data = {};
    try {
      data = await response.json();
    } catch {
      throw new Error("The game response could not be read.");
    }
    if (response.status === 401) {
      window.location.replace("/?scene=login");
      throw new Error("Please sign in to play.");
    }
    if (!response.ok) {
      const error = new Error(data.error || "The request could not be completed.");
      error.status = response.status;
      throw error;
    }
    return data;
  }

  async function loadWheelState() {
    try {
      const response = await fetch("/api/games/lucky-wheel/state", {
        credentials: "same-origin",
        cache: "no-store",
      });
      const data = await parseResponse(response);
      coins = Number(data.demoCoins);
      $("winChance").textContent = formatChance(data.winChancePercent);
      renderStats(data.stats);
      renderRecent(data.recentResults);
      renderWallet();
      updateSpinAvailability();
    } catch (error) {
      setStatus(error.message);
      updateSpinAvailability();
    }
  }

  function animateToSector(wheelIndex) {
    const sectorAngle = 36;
    const normalizedIndex = Math.max(0, Math.min(9, Number(wheelIndex) || 0));
    const pointerOffset = (360 - normalizedIndex * sectorAngle) % 360;
    const nextTurn = Math.ceil(currentRotation / 360) * 360 + 360 * 7 + pointerOffset;
    currentRotation = nextTurn;
    rotor.style.transform = `rotate(${nextTurn}deg)`;
    return new Promise(resolve => {
      let settled = false;
      const finish = () => {
        if (settled) return;
        settled = true;
        rotor.removeEventListener("transitionend", finish);
        resolve();
      };
      rotor.addEventListener("transitionend", finish, { once: true });
      window.setTimeout(finish, 3900);
    });
  }

  async function spinWheel() {
    if (isSpinning) return;
    const requestedBet = Number(betInput.value);
    if (!Number.isInteger(requestedBet) || requestedBet < 50 || requestedBet > 1000) {
      setStatus("Choose a whole-number bet from 50 to 1,000 Demo Coins.");
      return;
    }
    setBet(requestedBet);
    if (Number(coins) < selectedBet) {
      setStatus("Not enough Demo Coins for this bet.");
      return;
    }

    isSpinning = true;
    setStatus("The wheel is spinning…");
    updateSpinAvailability();
    try {
      const response = await fetch("/api/games/lucky-wheel/spin", {
        method: "POST",
        credentials: "same-origin",
        cache: "no-store",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ bet: selectedBet }),
      });
      const data = await parseResponse(response);
      await animateToSector(data.wheelIndex);
      coins = Number(data.demoCoins);
      renderWallet();
      renderStats(data.stats);
      renderRecent(data.recentResults);
      $("winChance").textContent = formatChance(data.winChancePercent);
      if (Number(data.reward) > 0) {
        setStatus(`WIN · ${data.resultLabel} · +${formatCoins(data.reward)} Demo Coins`, "win");
      } else {
        setStatus(`PLAY AGAIN · −${formatCoins(data.bet)} Demo Coins`, "loss");
      }
      await window.s999RefreshWallet();
    } catch (error) {
      if (error.status === 409) {
        await window.s999RefreshWallet();
      }
      setStatus(error.message);
    } finally {
      isSpinning = false;
      updateSpinAvailability();
    }
  }

  betButtons.forEach(button => {
    button.addEventListener("click", () => setBet(Number(button.dataset.bet)));
  });
  $("decreaseBet").addEventListener("click", () => setBet(selectedBet - 50));
  $("increaseBet").addEventListener("click", () => setBet(selectedBet + 50));
  betInput.addEventListener("change", () => setBet(betInput.value));
  mainSpinButton.addEventListener("click", spinWheel);
  centerSpinButton.addEventListener("click", spinWheel);

  setBet(selectedBet);
  Promise.resolve(window.s999WalletReady).finally(loadWheelState);
})();
