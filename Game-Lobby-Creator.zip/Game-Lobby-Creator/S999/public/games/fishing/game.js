const $ = id => document.getElementById(id);
function fishCatch(){let ok=Math.random()>.35;$('fish').textContent=ok?'🎣 🐟 ✨':'🎣 🌊 💦';$('gameStatus').textContent=ok?'You caught a fish!':'No catch this time.';}
