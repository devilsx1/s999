const $ = id => document.getElementById(id);
function drawCards(){let deck=['A♠','K♥','Q♦','J♣','10♠','9♥','8♦','7♣'];let a=[...deck].sort(()=>Math.random()-.5).slice(0,3);$('cards').textContent=a.join('  ');$('gameStatus').textContent='Cards dealt! Practice mode does not calculate full Teen Patti rankings.';}
