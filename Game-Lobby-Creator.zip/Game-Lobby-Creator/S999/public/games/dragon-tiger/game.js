(() => {
  const MIN_BET = 20;
  const MAX_BET = 20_000;
  let pick = "";
  let stakeStep = MIN_BET;
  let walletReady = false;
  let loading = false;
  let submitting = false;
  let tableState = null;
  let serverClockOffset = 0;
  let lastRevealedRound = "";
  let lastRoundId = "";
  const $ = id => document.getElementById(id);
  const status = $("result");
  const dealButton = $("deal");

  window.addEventListener("s999:wallet-updated", event => {
    walletReady = true;
    coins = Number(event.detail.demoCoins);
    renderWallet();
  });

  function announce(message) {
    status.textContent = message;
  }

  function showLoginIfNeeded(response) {
    if (response.status !== 401) return false;
    window.location.replace("/?scene=login");
    return true;
  }

  function renderCard(element, card, side, animate = false) {
    element.classList.remove("card-back", "card-face", "red", "black", "is-dealt");
    if (!card) {
      element.classList.add("card-back");
      element.replaceChildren();
      const mark = document.createElement("span");
      mark.className = "dt-card-back-mark";
      mark.textContent = "♛";
      element.append(mark);
      element.setAttribute("aria-label", `${side} card not revealed`);
      return;
    }

    const isRed = card.suit === "♥" || card.suit === "♦";
    element.classList.add("card-face", isRed ? "red" : "black");
    const rank = document.createElement("span");
    rank.className = "dt-card-rank";
    rank.textContent = card.rank;
    const suit = document.createElement("span");
    suit.className = "dt-card-suit";
    suit.textContent = card.suit;
    const center = document.createElement("span");
    center.className = "dt-card-center";
    center.textContent = card.suit;
    element.replaceChildren(rank, suit, center);
    element.setAttribute("aria-label", `${side} ${card.rank} of ${card.suit}`);
    if (animate) element.classList.add("is-dealt");
  }

  function formatCoins(amount) {
    return `${Number(amount).toLocaleString()} Demo Coins`;
  }

  function renderBetMessage(round, bet) {
    if (!round) {
      announce("Connecting to the shared table…");
      return;
    }
    if (!bet) {
      announce(round.status === "betting"
        ? "Choose Dragon, Tie, or Tiger above while betting is open."
        : round.status === "revealing"
          ? "Bets are closed. The cards are being revealed."
          : "Next round is opening soon.");
      return;
    }
    if (round.status !== "settled") {
      announce(`Your ${formatCoins(bet.amount)} bet is locked on ${bet.pick.toUpperCase()}.`);
      return;
    }
    if (bet.status === "won") {
      announce(`${round.winner.toUpperCase()} wins. ${formatCoins(bet.payout)} returned, including your stake.`);
    } else if (bet.status === "push") {
      announce(`Tie round. Your ${formatCoins(bet.payout)} stake has been returned.`);
    } else {
      announce(`${round.winner.toUpperCase()} wins. Your ${formatCoins(bet.amount)} bet did not win.`);
    }
  }

  function renderHistory(rounds) {
    const container = $("recentRounds");
    container.replaceChildren();
    if (!rounds?.length) {
      const empty = document.createElement("span");
      empty.className = "dt-history-empty";
      empty.textContent = "Waiting for the first result…";
      container.append(empty);
      return;
    }

    for (const round of [...rounds].reverse()) {
      const item = document.createElement("div");
      item.className = `dt-history-item ${round.winner}`;
      const winner = document.createElement("strong");
      const resultName = round.winner === "tie"
        ? "Tie"
        : round.winner === "dragon"
          ? "Dragon"
          : "Tiger";
      winner.textContent = round.winner === "tie"
        ? "="
        : round.winner === "dragon"
          ? "D"
          : "T";
      item.title = `Round ${round.id}: ${resultName}`;
      item.setAttribute("aria-label", item.title);
      item.append(winner);
      container.append(item);
    }
  }

  function renderTable() {
    if (!tableState) return;
    const round = tableState.currentRound;
    const bet = tableState.myBet;
    if (!round) {
      $("roundNumber").textContent = "—";
      $("roundPhase").textContent = "CONNECTING";
      $("roundPhase").dataset.phase = "connecting";
      $("countdown").textContent = "—";
      $("clockLabel").textContent = "SYNCING";
      renderBetMessage(null, null);
      return;
    }

    if (lastRoundId && round.id !== lastRoundId) pick = "";
    lastRoundId = round.id;
    $("roundNumber").textContent = `#${String(round.id).padStart(6, "0")}`;
    const phaseLabels = {
      betting: "BETTING OPEN",
      revealing: "DEALING",
      settled: "ROUND RESULT",
    };
    $("roundPhase").textContent = phaseLabels[round.status] || "LIVE";
    $("roundPhase").dataset.phase = round.status;

    if (round.status === "betting") {
      $("clockLabel").textContent = "BETTING CLOSES IN";
    } else if (round.status === "revealing") {
      $("clockLabel").textContent = "CARDS REVEAL IN";
    } else {
      $("clockLabel").textContent = "NEXT ROUND IN";
    }

    if (round.status === "settled") {
      const animateDeal = lastRevealedRound !== round.id;
      renderCard($("dragonCard"), round.dragon, "Dragon", animateDeal);
      renderCard($("tigerCard"), round.tiger, "Tiger", animateDeal);
      lastRevealedRound = round.id;
      $("dragonSide").classList.toggle("winner", round.winner === "dragon");
      $("tigerSide").classList.toggle("winner", round.winner === "tiger");
      $("tieSide").classList.toggle("winner", round.winner === "tie");
      $("roundResult").textContent = round.winner === "tie"
        ? "TIE · STAKES RETURNED"
        : `${round.winner.toUpperCase()} TAKES THE ROUND`;
      $("roundResult").dataset.result = round.winner;
    } else {
      renderCard($("dragonCard"), null, "Dragon");
      renderCard($("tigerCard"), null, "Tiger");
      $("dragonSide").classList.remove("winner");
      $("tigerSide").classList.remove("winner");
      $("tieSide").classList.remove("winner");
      $("roundResult").textContent = round.status === "revealing"
        ? "NO MORE BETS · DEALING CARDS"
        : "PLACE YOUR BET BEFORE THE TIMER ENDS";
      $("roundResult").dataset.result = "";
    }

    const now = Date.now() + serverClockOffset;
    const target = round.status === "betting"
      ? round.bettingEndsAt
      : round.status === "revealing"
        ? round.revealAt
        : round.nextRoundAt;
    const remaining = Math.max(0, new Date(target).getTime() - now);
    const seconds = Math.ceil(remaining / 1000);
    $("countdown").textContent = `00:${String(seconds).padStart(2, "0")}`;

    const canBet = walletReady &&
      round.status === "betting" &&
      new Date(round.bettingEndsAt).getTime() > now &&
      !bet &&
      !submitting;
    $("stake").disabled = !canBet;
    document.querySelectorAll("[data-stake], [data-stake-adjust]").forEach(button => {
      button.disabled = !canBet;
    });
    document.querySelectorAll("[data-pick]").forEach(button => {
      button.disabled = !canBet;
      const selected = button.dataset.pick === pick;
      button.classList.toggle("selected", selected);
      button.setAttribute("aria-pressed", String(selected));
    });
    dealButton.disabled = !canBet || !pick;
    dealButton.querySelector("strong").textContent = canBet
      ? "ONE BET PER ROUND"
      : bet
        ? "BET LOCKED"
        : round.status === "revealing"
          ? "DEALING CARDS"
          : round.status === "settled"
            ? "NEXT ROUND SOON"
            : "LOADING TABLE";

    renderBetMessage(round, bet);
    renderHistory(tableState.recentRounds);
  }

  async function loadState() {
    if (loading) return;
    loading = true;
    try {
      const requestStartedAt = Date.now();
      const response = await fetch("/api/games/dragon-tiger/state", {
        credentials: "same-origin",
        cache: "no-store",
      });
      if (showLoginIfNeeded(response)) return;
      const data = await response.json();
      const responseReceivedAt = Date.now();
      if (!response.ok) throw new Error(data.error || "Could not load the table.");
      tableState = data;
      serverClockOffset = new Date(data.serverTime).getTime()
        - (requestStartedAt + responseReceivedAt) / 2;
      walletReady = true;
      coins = Number(data.demoCoins);
      renderWallet();
      renderTable();
    } catch (error) {
      $("roundPhase").textContent = "RECONNECTING";
      $("roundPhase").dataset.phase = "connecting";
      announce(error.message || "The table is reconnecting…");
    } finally {
      loading = false;
    }
  }

  document.querySelectorAll("[data-pick]").forEach(button => {
    button.addEventListener("click", () => {
      pick = button.dataset.pick;
      renderTable();
    });
  });

  document.querySelectorAll("[data-stake]").forEach(button => {
    button.addEventListener("click", () => {
      stakeStep = Number(button.dataset.stake);
      $("stake").value = String(stakeStep);
      document.querySelectorAll("[data-stake]").forEach(chip => {
        const selected = chip === button;
        chip.classList.toggle("selected", selected);
        chip.setAttribute("aria-pressed", String(selected));
      });
    });
  });

  $("stake").addEventListener("input", () => {
    const amount = Number($("stake").value);
    if (Number.isSafeInteger(amount) && amount >= MIN_BET && amount <= MAX_BET) {
      stakeStep = amount;
    }
    document.querySelectorAll("[data-stake]").forEach(chip => {
      const selected = Number(chip.dataset.stake) === amount;
      chip.classList.toggle("selected", selected);
      chip.setAttribute("aria-pressed", String(selected));
    });
  });

  document.querySelectorAll("[data-stake-adjust]").forEach(button => {
    button.addEventListener("click", () => {
      const amount = Number($("stake").value) || MIN_BET;
      const direction = Number(button.dataset.stakeAdjust);
      $("stake").value = String(Math.min(
        MAX_BET,
        Math.max(MIN_BET, amount + direction * stakeStep),
      ));
    });
  });

  dealButton.addEventListener("click", async () => {
    if (!walletReady) {
      announce("Loading your account balance…");
      return;
    }
    if (!pick) {
      announce("First choose Dragon, Tie, or Tiger above.");
      return;
    }
    const amount = Number($("stake").value);
    if (!Number.isSafeInteger(amount) || amount < MIN_BET || amount > MAX_BET) {
      announce(`Enter a whole-number bet from ${MIN_BET} to ${MAX_BET.toLocaleString()} Demo Coins.`);
      return;
    }
    submitting = true;
    renderTable();
    dealButton.disabled = true;
    announce("Sending your bet to the shared table…");
    try {
      const response = await fetch("/api/games/dragon-tiger/bets", {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pick, amount }),
      });
      const data = await response.json();
      if (showLoginIfNeeded(response)) return;
      if (!response.ok) throw new Error(data.error || "The game could not be played.");

      coins = Number(data.demoCoins);
      renderWallet();
      announce(`Bet accepted for round ${data.bet.roundId}. Waiting for the server's card draw.`);
      await loadState();
    } catch (error) {
      announce(error.message || "The game could not be played.");
      await loadState();
    } finally {
      submitting = false;
      renderTable();
    }
  });

  loadState();
  window.setInterval(loadState, 500);
  window.setInterval(() => {
    if (!tableState?.currentRound) return;
    const now = Date.now() + serverClockOffset;
    const round = tableState.currentRound;
    const target = round.status === "betting"
      ? round.bettingEndsAt
      : round.status === "revealing"
        ? round.revealAt
        : round.nextRoundAt;
    const seconds = Math.max(0, Math.ceil((new Date(target).getTime() - now) / 1000));
    $("countdown").textContent = `00:${String(seconds).padStart(2, "0")}`;
  }, 200);
})();
