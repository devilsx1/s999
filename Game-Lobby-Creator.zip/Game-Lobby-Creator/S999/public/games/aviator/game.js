
"use strict";

let balance = 0;
let balanceReady = false;
const gameName = location.pathname.includes("/crash/") ? "crash" : "aviator";
let state = "idle";
let multiplier = 1;
let crashPoint = 1;
let startTime = 0;
let animation = null;
let roundTimer = null;
let countdownTimer = null;
let roundId = 0;
let totalWon = 0;
let records = [];
let fakeRecords = [];
let boardMode = "all";
let recent = [1.20, 1.15, 1.96, 2.20, 4.74, 1.05, 3.25];
let roundEndTime = 0;
let audioContext = null;
let soundEnabled = true;

const $ = id => document.getElementById(id);
const panels = [...document.querySelectorAll(".bet-panel")];

const slots = [
  { active: false, amount: 20, increment: 20, mode: "bet", target: 2, betId: null, processing: false },
  { active: false, amount: 20, increment: 20, mode: "bet", target: 2, betId: null, processing: false }
];

function money(n) {
  return Number(n).toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

const soundEffects = {
  start: { type: "triangle", from: 260, to: 520, duration: 0.22, volume: 0.035 },
  bet: { type: "sine", from: 540, to: 760, duration: 0.12, volume: 0.035 },
  cashout: { type: "triangle", from: 620, to: 1080, duration: 0.2, volume: 0.045 },
  crash: { type: "sawtooth", from: 300, to: 75, duration: 0.34, volume: 0.035 }
};

function getAudioContext() {
  const AudioContextClass = window.AudioContext || window.webkitAudioContext;
  if (!AudioContextClass) return null;
  if (!audioContext) {
    try {
      audioContext = new AudioContextClass();
    } catch {
      return null;
    }
  }
  return audioContext;
}

function unlockAudio() {
  if (!soundEnabled) return;
  const context = getAudioContext();
  if (context?.state === "suspended") context.resume().catch(() => {});
}

document.addEventListener("pointerdown", unlockAudio, true);
document.addEventListener("keydown", unlockAudio, true);

function playSound(name) {
  if (!soundEnabled) return;
  const context = getAudioContext();
  const effect = soundEffects[name];
  if (!context || !effect) return;
  if (context.state !== "running") {
    context.resume().catch(() => {});
    return;
  }

  const now = context.currentTime;
  const oscillator = context.createOscillator();
  const gain = context.createGain();
  oscillator.type = effect.type;
  oscillator.frequency.setValueAtTime(effect.from, now);
  oscillator.frequency.exponentialRampToValueAtTime(effect.to, now + effect.duration);
  gain.gain.setValueAtTime(0.0001, now);
  gain.gain.exponentialRampToValueAtTime(effect.volume, now + 0.018);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + effect.duration);
  oscillator.connect(gain);
  gain.connect(context.destination);
  oscillator.start(now);
  oscillator.stop(now + effect.duration + 0.01);
}

function updateSoundToggle() {
  const button = $("soundToggle");
  button.textContent = soundEnabled ? "🔊" : "🔇";
  button.setAttribute("aria-label", soundEnabled ? "Mute game sounds" : "Enable game sounds");
  button.setAttribute("aria-pressed", String(soundEnabled));
}

function updateBalance() {
  try {
    sessionStorage.setItem("s999_coins", String(balance));
  } catch {
    // The server balance is authoritative; storage is only a local convenience.
  }
  $("balance").textContent = "🪙 " + money(balance) + " virtual coins";
}

function readSavedBalance() {
  try {
    return Number(sessionStorage.getItem("s999_coins") || 0);
  } catch {
    return 0;
  }
}

async function gameRequest(url, body = {}) {
  const response = await fetch(url, {
    method: "POST",
    credentials: "same-origin",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  let data = {};
  try { data = await response.json(); } catch {}
  if (response.status === 401) {
    window.location.replace("/?scene=login");
    throw new Error("Please log in to continue.");
  }
  if (!response.ok) throw new Error(data.error || "Game action failed.");
  return data;
}

// Simulated multiplier. Randomness is not a prediction.
function generateCrashPoint() {
  const r = Math.random();

  if (r < 0.90) return 1.10 + Math.random() * 1.90;
  if (r < 0.99) return 3 + Math.random() * 7;
  if (r < 0.999) return 10 + Math.random() * 40;
  return 50 + Math.random() * 150;
}

function clearTimers() {
  clearTimeout(roundTimer);
  clearInterval(countdownTimer);
  roundTimer = null;
  countdownTimer = null;
}

function scheduleNextRound(seconds = 10) {
  clearTimers();

  state = "waiting";
  roundEndTime = Date.now() + seconds * 1000;

  $("multiplier").textContent = "1.00x";
  $("multiplier").style.color = "#fff";
  $("status").classList.remove("crashed");
  $("status").textContent = "NEXT ROUND IN";
  $("countdown").classList.remove("hidden");
  $("countdownValue").textContent = String(seconds);

  updatePanels();

  countdownTimer = setInterval(() => {
    if (state !== "waiting") {
      clearInterval(countdownTimer);
      return;
    }

    const left = Math.max(
      0,
      Math.ceil((roundEndTime - Date.now()) / 1000)
    );

    $("countdownValue").textContent = String(left);
  }, 200);

  roundTimer = setTimeout(() => {
    if (state === "waiting") startRound();
  }, seconds * 1000);
}

function startRound() {
  if (state !== "waiting") return;

  clearTimers();

  state = "flying";
  playSound("start");
  roundId++;
  multiplier = 1;
  crashPoint = generateCrashPoint();
  startTime = performance.now();

  $("status").classList.remove("crashed");
  $("status").textContent = "PLANE IS FLYING";
  $("countdown").classList.add("hidden");
  $("multiplier").textContent = "1.00x";
  $("multiplier").style.color = "#fff";

  $("screen").style.background =
    "radial-gradient(ellipse at 48% 48%, #7b2cff 0%, #30105c 42%, #100722 100%)";

  $("plane").style.opacity = "1";
  $("plane").style.left = "7%";
  $("plane").style.bottom = "8%";
  $("plane").style.transform = "rotate(-12deg)";
  $("plane").classList.remove("plane-exploding");

  $("trail").setAttribute("d", "");
  $("area").setAttribute("d", "");

  slots.forEach((slot, i) => {
    if (slot.active) {
      panels[i].querySelector(".panel-message").textContent =
        "Flying! Cash out before the crash.";
    }
  });

  updatePanels();
  animation = requestAnimationFrame(tick);
}

async function placeBet(index) {
  const slot = slots[index];
  const panel = panels[index];
  if (!balanceReady) {
    panel.querySelector(".panel-message").textContent = "Loading your account balance…";
    return;
  }
  if (slot.processing) return;
  if (slot.active && state === "flying") {
    await cashOut(index);
    return;
  }
  slot.processing = true;
  updatePanels();

  try {
    // An existing bet can be cancelled during the countdown.
    if (slot.active && state === "waiting") {
      const result = await gameRequest(`/api/games/bets/${slot.betId}/cancel`);
      slot.active = false;
      slot.betId = null;
      balance = Number(result.demoCoins);
      panel.querySelector(".panel-message").textContent =
        "Bet cancelled. Demo Coins returned.";
      addRecord("Bet cancelled", slot.amount, null, index);
      return;
    }

    // Do not accept new bets after the plane starts flying.
    if (state !== "waiting") {
      panel.querySelector(".panel-message").textContent =
        "Wait for the next 10-second betting window.";
      return;
    }

    const amount = Number(panel.querySelector(".amount").value);
    if (!Number.isSafeInteger(amount) || amount < 1) {
      panel.querySelector(".panel-message").textContent =
        "Enter a whole-number bet of at least 1.";
      return;
    }
    if (amount > balance) {
      panel.querySelector(".panel-message").textContent =
        "Not enough Demo Coins.";
      return;
    }

    const result = await gameRequest("/api/games/bets", { game: gameName, amount });
    slot.amount = amount;
    slot.betId = result.betId;
    slot.active = true;
    balance = Number(result.demoCoins);
    playSound("bet");
    panel.querySelector(".panel-message").textContent =
      slot.mode === "auto"
        ? `Auto cash out target: ${slot.target.toFixed(2)}x`
        : "Bet accepted! Waiting for flight.";
    addRecord("Bet placed", amount, null, index);
  } catch (error) {
    panel.querySelector(".panel-message").textContent = error.message;
  } finally {
    slot.processing = false;
    updateBalance();
    updatePanels();
  }
}

async function cashOut(index) {
  const slot = slots[index];
  if (state !== "flying" || !slot.active || slot.processing || !slot.betId) return;
  slot.processing = true;
  updatePanels();
  try {
    const cashoutMultiplier = Math.max(1, Math.min(200, multiplier));
    const result = await gameRequest(
      `/api/games/bets/${slot.betId}/cashout`,
      { multiplier: cashoutMultiplier }
    );
    const payout = Number(result.payout);
    slot.active = false;
    slot.betId = null;
    balance = Number(result.demoCoins);
    totalWon += payout;
    playSound("cashout");
    panels[index].querySelector(".panel-message").textContent =
      `Cashed out at ${cashoutMultiplier.toFixed(2)}x · Payout ${money(payout)}`;
    addRecord("Cashed out", slot.amount, payout, index);
  } catch (error) {
    panels[index].querySelector(".panel-message").textContent = error.message;
  } finally {
    slot.processing = false;
    updateBalance();
    updatePanels();
  }
}

function tick(now) {
  if (state !== "flying") return;

  const elapsed = (now - startTime) / 1000;
  const current = Math.exp(elapsed * 0.34);

  if (current >= crashPoint) {
    multiplier = crashPoint;
    $("multiplier").textContent = multiplier.toFixed(2) + "x";
    finishRound();
    return;
  }

  multiplier = current;
  $("multiplier").textContent = multiplier.toFixed(2) + "x";

  const x = Math.min(88, 7 + elapsed * 7);
  const y = Math.min(76, 8 + elapsed * 5);

  $("plane").style.left = x + "%";
  $("plane").style.bottom = y + "%";
  $("plane").style.transform =
    `rotate(-${Math.min(35, 12 + elapsed * 2)}deg)`;

  const px = x * 10;
  const py = 560 - y * 5.6;
  const cx = Math.max(140, px - 120);
  const cy = Math.max(45, py + 95);

  const curve = `M 25 520 Q ${cx} ${cy} ${px} ${py}`;

  $("trail").setAttribute("d", curve);
  $("area").setAttribute("d", `${curve} L ${px} 560 L 25 560 Z`);

  slots.forEach((slot, i) => {
    if (
      slot.active &&
      slot.mode === "auto" &&
      multiplier >= slot.target
    ) {
      cashOut(i);
    }
  });

  updatePanels();
  animation = requestAnimationFrame(tick);
}

function finishRound() {
  state = "ended";

  cancelAnimationFrame(animation);
  animation = null;
  playSound("crash");
  $("plane").classList.add("plane-exploding");
  $("countdown").classList.add("hidden");

  $("multiplier").style.color = "#ff3155";
  $("status").classList.add("crashed");
  $("status").textContent = `PLANE CRASHED · ${multiplier.toFixed(2)}x`;

  $("screen").style.background =
    "radial-gradient(ellipse at center, #8b24ff 0%, #3b126f 48%, #130824 100%)";

  slots.forEach((slot, i) => {
    if (slot.active) {
      slot.active = false;
      const betId = slot.betId;
      slot.betId = null;
      if (betId) {
        gameRequest(`/api/games/bets/${betId}/lose`).catch(error => {
          panels[i].querySelector(".panel-message").textContent = error.message;
        });
      }

      panels[i].querySelector(".panel-message").textContent =
        `Crashed at ${multiplier.toFixed(2)}x — bet lost.`;

      addRecord("Crashed", slot.amount, 0, i);
    }
  });

  recent.unshift(multiplier);
  recent = recent.slice(0, 12);

  for (let i = 0; i < 4; i++) {
    fakeRecords.unshift(makeFakeRecord(crashPoint, null, roundId));
  }
  fakeRecords = fakeRecords.slice(0, 12);

  renderRecent();
  renderFakeHistory();
  updatePanels();
  renderBoard();

  // Crash ke baad 10 seconds ka betting window.
  roundTimer = setTimeout(() => {
    if (state === "ended") {
      scheduleNextRound(10);
    }
  }, 1800);
}

function updatePanels() {
  panels.forEach((panel, i) => {
    const slot = slots[i];
    const button = panel.querySelector(".bet-button");
    const label = panel.querySelector(".bet-label");
    const value = panel.querySelector(".bet-value");

    panel.querySelector(".amount").disabled = slot.active || slot.processing || !balanceReady;

    panel.querySelectorAll(
      ".quick-amounts button, .minus, .plus"
    ).forEach(b => b.disabled = slot.active || slot.processing || !balanceReady);

    button.classList.remove("cashing", "cashed", "canceling");
    button.disabled = slot.processing || !balanceReady;

    if (slot.active && state === "waiting") {
      button.classList.add("canceling");
      label.textContent = "Cancel";
      value.textContent = money(slot.amount);
    } else if (slot.active && state === "flying") {
      button.classList.add("cashing");
      label.textContent = "CASH OUT";
      value.textContent = money(slot.amount * multiplier);
    } else {
      label.textContent = "Bet";
      value.textContent = money(slot.amount);
    }
  });

  $("totalWon").textContent = money(totalWon);
}

function renderRecent() {
  const container = $("recentRounds");
  container.replaceChildren();

  recent.forEach(value => {
    const item = document.createElement("span");
    item.className = "recent";

    if (value < 2) item.classList.add("blue");
    else if (value < 10) item.classList.add("purple");
    else item.classList.add("pink");

    item.textContent = value.toFixed(2) + "x";
    container.appendChild(item);
  });
}

function addRecord(action, amount, win, index) {
  records.unshift({ action, amount, win, index, round: roundId });
  records = records.slice(0, 60);

  $("betCount").textContent = records.length + " activities";
  renderBoard();
}

function makeFakeRecord(crash, player = null, round = 1) {
  const avatars = ["🦊", "🐼", "🐯", "🐨", "🦁", "🐸", "🐵", "🐧", "🐱"];
  const amount = (Math.floor(Math.random() * 99) + 2) * 5;
  const cashedOut = crash > 1.08 && Math.random() < 0.64;
  const cashoutMultiplier = cashedOut
    ? 1.01 + Math.random() * (crash - 1.01)
    : null;

  return {
    player: player || `Player${Math.floor(100000 + Math.random() * 900000)}`,
    avatar: avatars[Math.floor(Math.random() * avatars.length)],
    amount,
    round,
    crash,
    cashedOut,
    cashoutMultiplier,
    payout: cashedOut ? amount * cashoutMultiplier : 0
  };
}

function renderFakeHistory() {
  const list = $("fakeHistoryList");
  list.replaceChildren();

  fakeRecords.forEach(record => {
    const row = document.createElement("div");
    row.className = `fake-history-row ${record.cashedOut ? "winner" : ""}`;

    const player = document.createElement("div");
    player.className = "fake-player";

    const avatar = document.createElement("span");
    avatar.className = "fake-avatar";
    avatar.textContent = record.avatar;
    avatar.setAttribute("role", "img");
    avatar.setAttribute("aria-label", `${record.player} simulated avatar`);

    const identity = document.createElement("div");
    identity.className = "fake-player-identity";

    const name = document.createElement("strong");
    name.textContent = record.player;

    const detail = document.createElement("small");
    detail.textContent = `Round ${record.round}`;
    identity.append(name, detail);
    player.append(avatar, identity);

    const bet = document.createElement("span");
    bet.className = "fake-history-value";
    bet.textContent = record.amount.toLocaleString("en-US", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });

    const multiplier = document.createElement("span");
    multiplier.className = `fake-history-multiplier ${record.cashedOut ? "win" : ""}`;
    multiplier.textContent = record.cashedOut
      ? record.cashoutMultiplier.toFixed(2) + "x"
      : "—";

    const payout = document.createElement("strong");
    payout.className = `fake-history-payout ${record.cashedOut ? "win" : ""}`;
    payout.textContent = record.cashedOut
      ? record.payout.toLocaleString("en-US", {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2
        })
      : "—";

    row.append(player, bet, multiplier, payout);
    list.appendChild(row);
  });
}

function renderBoard() {
  const list = $("betsList");
  list.replaceChildren();

  let items = [...records];

  if (boardMode === "previous") {
    items = items.filter(r => r.action !== "Bet placed");
  }

  if (boardMode === "top") {
    items = items
      .filter(r => r.win !== null && r.win > 0)
      .sort((a, b) => b.win - a.win);
  }

  if (!items.length) {
    const empty = document.createElement("p");
    empty.className = "empty";
    empty.textContent = "No activity to display yet.";
    list.appendChild(empty);
    return;
  }

  items.slice(0, 12).forEach(record => {
    const row = document.createElement("div");
    row.className = "bet-row";

    const left = document.createElement("div");
    left.textContent = `Panel ${record.index + 1} · ${record.action}`;

    const detail = document.createElement("small");
    detail.textContent =
      `Round ${record.round} · Bet ${money(record.amount)}`;
    left.appendChild(detail);

    const right = document.createElement("strong");

    if (record.win === null) {
      right.textContent = money(record.amount);
    } else if (record.win > 0) {
      right.textContent = "+" + money(record.win);
      right.className = "win";
    } else {
      right.textContent = money(0);
      right.className = "loss";
    }

    row.append(left, right);
    list.appendChild(row);
  });
}

function updateQuickAmountSelection(panel, increment) {
  panel.querySelectorAll(".quick-amounts [data-amount]").forEach(button => {
    const selected = Number(button.dataset.amount) === Number(increment);
    button.classList.toggle("selected", selected);
    button.setAttribute("aria-pressed", String(selected));
  });
}

const soundToggle = $("soundToggle");
soundToggle.addEventListener("click", () => {
  soundEnabled = !soundEnabled;
  updateSoundToggle();
  if (soundEnabled) unlockAudio();
});
updateSoundToggle();

// Betting panel controls.
panels.forEach((panel, i) => {
  const slot = slots[i];
  updateQuickAmountSelection(panel, slot.increment);

  panel.querySelector(".bet-button").addEventListener("click", () => {
    placeBet(i);
  });

  panel.querySelector(".minus").addEventListener("click", () => {
    if (slot.active) return;

    const input = panel.querySelector(".amount");
    input.value = Math.max(1, (Number(input.value) || 1) - 1);
    slot.amount = Number(input.value);
    updatePanels();
  });

  panel.querySelector(".plus").addEventListener("click", () => {
    if (slot.active) return;

    const input = panel.querySelector(".amount");
    const increment = slot.increment || 20;
    input.value = (Number(input.value) || 0) + increment;

    slot.amount = Number(input.value);
    updatePanels();
  });

  panel.querySelector(".amount").addEventListener("input", event => {
    if (slot.active) return;

    slot.amount = Number(event.target.value) || 0;
      panel.querySelector(".bet-value").textContent = money(slot.amount);
  });

  panel.querySelectorAll("[data-amount]").forEach(button => {
    button.addEventListener("click", () => {
      if (slot.active) return;

      const input = panel.querySelector(".amount");
      slot.increment = Number(button.dataset.amount);
      input.value = slot.increment;
      slot.amount = Number(input.value);
      updateQuickAmountSelection(panel, slot.increment);
      updatePanels();
    });
  });

  panel.querySelectorAll(".mode").forEach(button => {
    button.addEventListener("click", () => {
      if (slot.active) return;

      slot.mode = button.dataset.mode;

      panel.querySelectorAll(".mode").forEach(b => {
        b.classList.toggle("active", b === button);
      });

      panel.querySelector(".auto-target").classList.toggle(
        "hidden",
        slot.mode !== "auto"
      );
    });
  });

  panel.querySelector(".target").addEventListener("change", event => {
    const target = Number(event.target.value);

    slot.target =
      Number.isFinite(target) && target >= 1.01
        ? Math.min(1000, target)
        : 2;

    event.target.value = slot.target.toFixed(2);
  });
});

// Activity tabs.
document.querySelectorAll(".board-tab").forEach(button => {
  button.addEventListener("click", () => {
    boardMode = button.dataset.board;

    document.querySelectorAll(".board-tab").forEach(tab => {
      tab.classList.toggle("active", tab === button);
    });

    renderBoard();
  });
});

// Reset game.
$("reset").addEventListener("click", () => {
  if (slots.some(slot => slot.active || slot.processing)) {
    alert("Cancel or finish active bets before resetting game history.");
    return;
  }
  if (!confirm("Reset game history? Your S999 virtual coin balance will be kept.")) return;

  cancelAnimationFrame(animation);
  animation = null;
  clearTimers();

  state = "idle";
  balance = readSavedBalance();
  multiplier = 1;
  totalWon = 0;
  records = [];
  roundId = 0;

  slots.forEach((slot, i) => {
    slot.active = false;
    slot.betId = null;
    slot.processing = false;
    slot.amount = 20;
    slot.increment = 20;
    slot.mode = "bet";
    slot.target = 2;

    const panel = panels[i];

    panel.querySelector(".amount").value = "20";
    updateQuickAmountSelection(panel, slot.increment);
    panel.querySelector(".target").value = "2.00";
    panel.querySelector(".panel-message").textContent = "";

    panel.querySelectorAll(".mode").forEach(button => {
      button.classList.toggle("active", button.dataset.mode === "bet");
    });

    panel.querySelector(".auto-target").classList.add("hidden");
  });

  document.querySelectorAll(".board-tab").forEach(tab => {
    tab.classList.toggle("active", tab.dataset.board === "all");
  });

  $("plane").style.opacity = "1";
  $("plane").style.left = "7%";
  $("plane").style.bottom = "8%";
  $("plane").style.transform = "rotate(-12deg)";
  $("plane").classList.remove("plane-exploding");
  $("trail").setAttribute("d", "");
  $("area").setAttribute("d", "");
  $("screen").style.background = "";

  updateBalance();
  updatePanels();
  renderRecent();
  renderBoard();

  scheduleNextRound(10);
});

// Initial page load: open the first 10-second betting window.
updateBalance();
updatePanels();
renderRecent();
renderBoard();
fakeRecords = [
  makeFakeRecord(2.14, "Player258042", 8),
  makeFakeRecord(1.72, null, 8),
  makeFakeRecord(4.31, null, 7),
  makeFakeRecord(1.39, null, 7),
  makeFakeRecord(3.08, null, 6),
  makeFakeRecord(1.22, null, 6),
  makeFakeRecord(5.67, null, 5),
  makeFakeRecord(1.91, null, 5),
  makeFakeRecord(2.75, null, 4),
  makeFakeRecord(1.48, null, 4),
  makeFakeRecord(3.62, null, 3),
  makeFakeRecord(1.16, null, 3)
];
renderFakeHistory();
scheduleNextRound(10);

window.s999WalletReady?.then(data => {
  if (!data) return;
  balance = Number(data.demoCoins);
  balanceReady = true;
  updateBalance();
  updatePanels();
});

window.addEventListener("s999:wallet-updated", event => {
  if (!slots.some(slot => slot.active || slot.processing)) {
    balance = Number(event.detail.demoCoins);
    balanceReady = true;
    updateBalance();
    updatePanels();
  }
});
