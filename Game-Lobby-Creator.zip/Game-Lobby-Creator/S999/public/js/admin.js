
(() => {
  const $ = id => document.getElementById(id);
  const loginView = $('adminLoginView');
  const dashboard = $('adminDashboard');
  const loginForm = $('adminLoginForm');
  const loginNotice = $('adminLoginNotice');
  const dashboardNotice = $('dashboardNotice');
  const rows = $('requestRows');
  const emptyState = $('emptyRequests');
  const requestTypeButtons = [...document.querySelectorAll('[data-request-type]')];
  const adminTabButtons = [...document.querySelectorAll('[data-admin-tab]')];
  const adminTabPanels = [...document.querySelectorAll('[data-admin-panel]')];
  const wheelChanceSlider = $('wheelWinChance');
  const wheelChanceOutput = $('wheelWinChanceValue');
  let activeRequestType = 'deposit';
  let activeAdminTab = 'requests';
  let refreshTimer;

  async function api(url, options = {}) {
    const headers = {...(options.headers || {})};
    if (options.body) headers['Content-Type'] = 'application/json';
    const response = await fetch(url, {
      ...options,
      headers,
      credentials: 'same-origin',
      cache: 'no-store'
    });
    let data = {};
    try { data = await response.json(); } catch {}
    if (!response.ok) {
      const error = new Error(data.error || 'Request failed.');
      error.status = response.status;
      throw error;
    }
    return data;
  }

  function formatChance(value) {
    return `${Number(value).toLocaleString(undefined, {maximumFractionDigits: 1})}%`;
  }

  function updateWheelChanceDisplay() {
    const value = Number(wheelChanceSlider.value);
    const progress = ((value - Number(wheelChanceSlider.min)) /
      (Number(wheelChanceSlider.max) - Number(wheelChanceSlider.min))) * 100;
    wheelChanceOutput.value = formatChance(value);
    wheelChanceSlider.setAttribute('aria-valuetext', formatChance(value));
    wheelChanceSlider.style.setProperty('--range-progress', `${progress}%`);
  }

  function loadActiveAdminTab() {
    if (activeAdminTab === 'requests') return loadDashboard();
    if (activeAdminTab === 'lucky-wheel') return loadLuckyWheelDashboard();
    if (['aviator', 'crash', 'dragon-tiger'].includes(activeAdminTab)) {
      return loadGamesDashboard();
    }
  }

  function selectAdminTab(tabName) {
    if (!adminTabPanels.some(panel => panel.dataset.adminPanel === tabName)) return;
    activeAdminTab = tabName;
    adminTabButtons.forEach(button => {
      const isActive = button.dataset.adminTab === tabName;
      button.classList.toggle('is-active', isActive);
      button.setAttribute('aria-selected', String(isActive));
    });
    adminTabPanels.forEach(panel => {
      panel.hidden = panel.dataset.adminPanel !== tabName;
    });
    loadActiveAdminTab();
  }

  function setLoggedIn(isLoggedIn) {
    loginView.classList.toggle('hidden', isLoggedIn);
    dashboard.classList.toggle('hidden', !isLoggedIn);
    if (isLoggedIn) {
      loadActiveAdminTab();
      clearInterval(refreshTimer);
      refreshTimer = setInterval(loadActiveAdminTab, 20_000);
    } else {
      clearInterval(refreshTimer);
    }
  }

  function formatDate(value) {
    return new Intl.DateTimeFormat(undefined, {
      dateStyle: 'medium',
      timeStyle: 'short'
    }).format(new Date(value));
  }

  async function loadLuckyWheelDashboard() {
    const notice = $('luckyWheelAdminNotice');
    try {
      const data = await api('/api/admin/lucky-wheel');
      const today = data.today || {};
      wheelChanceSlider.value = String(Math.round(Number(data.winChancePercent)));
      updateWheelChanceDisplay();
      $('wheelTodaySpins').textContent = Number(today.totalSpins || 0).toLocaleString();
      $('wheelTodayWins').textContent = Number(today.totalWins || 0).toLocaleString();
      $('wheelTodayLosses').textContent = Number(today.totalLosses || 0).toLocaleString();
      $('wheelTodayStaked').textContent = Number(today.totalStaked || 0).toLocaleString();
      $('wheelTodayAwarded').textContent = Number(today.totalAwarded || 0).toLocaleString();
      const net = Number(today.netProfit || 0);
      $('wheelTodayNet').textContent = `${net > 0 ? '+' : ''}${net.toLocaleString()}`;
      if (!notice.textContent) {
        notice.textContent = `Current player-visible chance: ${formatChance(data.winChancePercent)}.`;
      }
    } catch (error) {
      if (error.status === 401) {
        setLoggedIn(false);
        loginNotice.textContent = 'Your admin session expired. Sign in again.';
        return;
      }
      notice.textContent = error.message;
    }
  }

  async function loadGamesDashboard() {
    const noticeIds = ['aviatorAdminNotice', 'crashAdminNotice', 'dragonTigerAdminNotice'];
    noticeIds.forEach(id => { $(id).textContent = ''; });
    try {
      const data = await api('/api/admin/games/stats');
      const games = data.games || {};
      const update = (id, value) => {
        $(id).textContent = Number(value || 0).toLocaleString();
      };
      for (const game of ['aviator', 'crash']) {
        const stats = games[game] || {};
        const prefix = game === 'aviator' ? 'aviator' : 'crash';
        update(`${prefix}TodayBets`, stats.todayBets);
        update(`${prefix}ActiveBets`, stats.activeBets);
        update(`${prefix}TodayWins`, stats.todayWins);
        update(`${prefix}TodayLosses`, stats.todayLosses);
        update(`${prefix}TodayWagered`, stats.todayWagered);
        update(`${prefix}TodayPaidOut`, stats.todayPaidOut);
      }

      const dragonTiger = data.dragonTiger || {};
      update('dragonRoundsToday', dragonTiger.todayRounds);
      update('dragonTodayBets', dragonTiger.todayBets);
      update('dragonActiveBets', dragonTiger.activeBets);
      update('dragonTodayWins', dragonTiger.todayWins);
      update('dragonTodayLosses', dragonTiger.todayLosses);
      update('dragonPushes', dragonTiger.pushes);
      update('dragonWageredToday', dragonTiger.todayWagered);
      update('dragonPaidOutToday', dragonTiger.todayPaidOut);
    } catch (error) {
      if (error.status === 401) {
        setLoggedIn(false);
        loginNotice.textContent = 'Your admin session expired. Sign in again.';
        return;
      }
      noticeIds.forEach(id => { $(id).textContent = error.message; });
    }
  }

  function cell(row, className = '') {
    const element = document.createElement('td');
    if (className) element.className = className;
    row.append(element);
    return element;
  }

  function createAction(label, className, handler) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `action-button ${className}`;
    button.textContent = label;
    button.addEventListener('click', handler);
    return button;
  }

  function renderRequests(requests) {
    rows.replaceChildren();
    emptyState.classList.toggle('hidden', requests.length > 0);

    for (const request of requests) {
      const row = document.createElement('tr');

      const playerCell = cell(row, 'player-cell');
      const playerName = document.createElement('strong');
      playerName.textContent = request.player.fullName;
      const playerEmail = document.createElement('span');
      playerEmail.textContent = request.player.email;
      const playerPhone = document.createElement('span');
      playerPhone.textContent = request.player.phone || 'No phone';
      playerCell.append(playerName, playerEmail, playerPhone);

      const amount = cell(row, 'amount-cell');
      amount.textContent = `${Number(request.amount).toLocaleString()} Demo Coins`;

      // DEPOSIT DETAILS UPDATED
      const details = cell(row);

      if (activeRequestType === 'withdrawal') {
        // Original withdrawal details - unchanged
        details.textContent =
          `${request.provider === 'easypaisa'
            ? 'EasyPaisa'
            : 'JazzCash'} · ${request.accountPhone} · Demo Coins only`;

      } else {
        // Show user-submitted deposit details
        const depositFields = [
          ['Sender Name', request.senderName],
          ['Sender Number', request.senderNumber],
          ['TRX ID', request.trxId]
        ];

        for (const [label, value] of depositFields) {
          const line = document.createElement('div');
          const strong = document.createElement('strong');

          strong.textContent = label + ': ';

          line.append(
            strong,
            document.createTextNode(
              value !== undefined &&
              value !== null &&
              String(value).trim() !== ''
                ? String(value)
                : 'Not provided'
            )
          );

          line.style.marginBottom = '6px';
          details.append(line);
        }
      }

      const submitted = cell(row, 'request-meta');
      submitted.textContent = formatDate(request.createdAt);

      const status = cell(row);
      const statusPill = document.createElement('span');
      statusPill.className = `status-pill status-${request.status}`;
      statusPill.textContent = request.status;
      status.append(statusPill);

      const actions = cell(row);
      if (request.status === 'pending') {
        const group = document.createElement('div');
        group.className = 'action-group';
        group.append(
          createAction('Accept', 'action-accept', () => review(request, 'accept')),
          createAction('Reject', 'action-reject', () => review(request, 'reject'))
        );
        actions.append(group);
      } else {
        actions.textContent = request.adminNote || 'Reviewed';
      }

      rows.append(row);
    }
  }

  async function loadDashboard() {
    dashboardNotice.textContent = '';
    try {
      const requestEndpoint = activeRequestType === 'withdrawal'
        ? '/api/admin/withdrawal-requests'
        : '/api/admin/deposit-requests';

      const [summary, result] = await Promise.all([
        api('/api/admin/summary'),
        api(`${requestEndpoint}?status=${encodeURIComponent($('statusFilter').value)}`)
      ]);

      const stats = activeRequestType === 'withdrawal'
        ? {
            pending: summary.withdrawal_pending,
            accepted: summary.withdrawal_accepted,
            rejected: summary.withdrawal_rejected
          }
        : {
            pending: summary.deposit_pending,
            accepted: summary.deposit_accepted,
            rejected: summary.deposit_rejected
          };

      const label = activeRequestType === 'withdrawal' ? 'withdrawal' : 'deposit';
      $('requestHeading').textContent = `${activeRequestType === 'withdrawal' ? 'Withdrawal' : 'Deposit'} requests`;
      $('requestDescription').textContent = activeRequestType === 'withdrawal'
        ? 'Review the provider and linked number; each request can be reviewed once.'
        : 'Each request can be reviewed once.';
      $('pendingLabel').textContent = `Pending ${label}s`;
      $('acceptedLabel').textContent = `Accepted ${label}s`;
      $('rejectedLabel').textContent = `Rejected ${label}s`;
      emptyState.textContent = `No ${label} requests in this view.`;
      $('pendingCount').textContent = Number(stats.pending).toLocaleString();
      $('acceptedCount').textContent = Number(stats.accepted).toLocaleString();
      $('rejectedCount').textContent = Number(stats.rejected).toLocaleString();
      $('playerCount').textContent = Number(summary.players).toLocaleString();

      renderRequests(result.requests);
    } catch (error) {
      if (error.status === 401) {
        setLoggedIn(false);
        loginNotice.textContent = 'Your admin session expired. Sign in again.';
        return;
      }
      dashboardNotice.textContent = error.message;
    }
  }

  async function review(request, action) {
    const isWithdrawal = activeRequestType === 'withdrawal';
    const amount = Number(request.amount).toLocaleString();
    const provider = request.provider === 'easypaisa' ? 'EasyPaisa' : 'JazzCash';

    const prompt = isWithdrawal
      ? action === 'accept'
        ? `Approve this ${provider} Demo Coin request for ${amount} coins? No cash payment will be sent.`
        : `Reject this request and return ${amount} Demo Coins to the player?`
      : action === 'accept'
        ? 'Accept this request and credit the Demo Coins to the player?'
        : 'Reject this Demo Coin request?';

    if (!window.confirm(prompt)) return;

    dashboardNotice.textContent = 'Saving review…';
    try {
      const base = isWithdrawal ? 'withdrawal-requests' : 'deposit-requests';
      await api(`/api/admin/${base}/${request.id}/${action}`, {
        method: 'POST',
        body: JSON.stringify({})
      });

      dashboardNotice.textContent = isWithdrawal
        ? action === 'accept'
          ? 'Demo Coin request approved. No cash payment was sent.'
          : 'Request rejected and Demo Coins returned to the player.'
        : action === 'accept'
          ? 'Request accepted and Demo Coins credited.'
          : 'Request rejected.';

      await loadDashboard();
    } catch (error) {
      dashboardNotice.textContent = error.message;
    }
  }

  loginForm.addEventListener('submit', async event => {
    event.preventDefault();
    const button = loginForm.querySelector('button[type="submit"]');
    button.disabled = true;
    loginNotice.textContent = 'Signing in…';

    try {
      await api('/api/admin/login', {
        method: 'POST',
        body: JSON.stringify({password: $('adminPassword').value})
      });
      loginForm.reset();
      loginNotice.textContent = '';
      setLoggedIn(true);
    } catch (error) {
      loginNotice.textContent = error.message;
    } finally {
      button.disabled = false;
    }
  });

  requestTypeButtons.forEach(button => {
    button.addEventListener('click', () => {
      activeRequestType = button.dataset.requestType === 'withdrawal' ? 'withdrawal' : 'deposit';
      requestTypeButtons.forEach(tab => {
        const isActive = tab === button;
        tab.classList.toggle('is-active', isActive);
        tab.setAttribute('aria-selected', String(isActive));
      });
      loadDashboard();
    });
  });

  $('statusFilter').addEventListener('change', loadDashboard);

  adminTabButtons.forEach(button => {
    button.addEventListener('click', () => selectAdminTab(button.dataset.adminTab));
  });

  $('refreshRequests').addEventListener('click', loadActiveAdminTab);

  document.querySelectorAll('[data-refresh-games]').forEach(button => {
    button.addEventListener('click', loadGamesDashboard);
  });

  $('refreshLuckyWheel').addEventListener('click', loadLuckyWheelDashboard);
  wheelChanceSlider.addEventListener('input', updateWheelChanceDisplay);

  $('luckyWheelSettingsForm').addEventListener('submit', async event => {
    event.preventDefault();
    const button = $('saveLuckyWheelSettings');
    const notice = $('luckyWheelAdminNotice');
    const winChancePercent = Number($('wheelWinChance').value);
    button.disabled = true;
    notice.textContent = 'Saving the displayed win chance…';

    try {
      const result = await api('/api/admin/lucky-wheel/settings', {
        method: 'PATCH',
        body: JSON.stringify({winChancePercent})
      });
      notice.textContent = `Saved. Players now see a ${formatChance(result.winChancePercent)} win chance.`;
      await loadLuckyWheelDashboard();
      notice.textContent = `Saved. Players now see a ${formatChance(result.winChancePercent)} win chance.`;
    } catch (error) {
      if (error.status === 401) {
        setLoggedIn(false);
        loginNotice.textContent = 'Your admin session expired. Sign in again.';
        return;
      }
      notice.textContent = error.message;
    } finally {
      button.disabled = false;
    }
  });

  $('adminLogout').addEventListener('click', async () => {
    try {
      await api('/api/admin/logout', {
        method: 'POST',
        body: JSON.stringify({})
      });
      setLoggedIn(false);
      loginNotice.textContent = 'You have logged out.';
    } catch (error) {
      dashboardNotice.textContent = error.message;
    }
  });

  updateWheelChanceDisplay();

  api('/api/admin/session')
    .then(result => setLoggedIn(result.authenticated))
    .catch(error => {
      loginNotice.textContent = error.message;
    });
})();
