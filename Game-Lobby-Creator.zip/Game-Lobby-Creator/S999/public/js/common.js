// Use a unique helper name because each classic game script may define its own "$".
const getS999WalletElement = id => document.getElementById(id);
let coins = 0;
let history = [];
let walletSyncInFlight = false;

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'
  })[char]);
}

function renderWallet() {
  getS999WalletElement('walletRetry')?.remove();
  document.querySelectorAll('[data-coins]').forEach(element => {
    element.textContent = coins.toLocaleString();
  });
  const historyElement = getS999WalletElement('history');
  if (historyElement) {
    historyElement.innerHTML = history.length
      ? history.map(item => '• ' + escapeHtml(item)).join('<br>')
      : 'No activity yet.';
  }
}

async function refreshWallet() {
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), 12000);
  try {
    const response = await fetch('/api/wallet', {
      credentials: 'same-origin',
      cache: 'no-store',
      signal: controller.signal
    });
    if (response.status === 401) {
      window.location.replace('/?scene=login');
      return null;
    }
    if (!response.ok) {
      throw new Error('Could not load the account balance.');
    }
    const data = await response.json();
    const nextCoins = Number(data.demoCoins);
    if (!Number.isFinite(nextCoins)) {
      throw new Error('The balance response was invalid.');
    }
    coins = nextCoins;
    history = (data.activity || []).map(item => item.label);
    try {
      sessionStorage.setItem('s999_coins', String(coins));
    } catch {
      // Balance API data remains authoritative if browser storage is unavailable.
    }
    renderWallet();
    window.dispatchEvent(new CustomEvent('s999:wallet-updated', {detail: data}));
    return data;
  } finally {
    window.clearTimeout(timeout);
  }
}

function showWalletError() {
  const balanceElement = getS999WalletElement('balance');
  if (balanceElement) {
    balanceElement.textContent = '🪙 Balance unavailable';
    balanceElement.setAttribute('aria-live', 'polite');
  }
  document.querySelectorAll('[data-coins]').forEach(element => {
    element.textContent = '—';
  });

  const wallet = document.querySelector('.wallet');
  if (!wallet || getS999WalletElement('walletRetry')) return;
  const retryButton = document.createElement('button');
  retryButton.id = 'walletRetry';
  retryButton.type = 'button';
  retryButton.textContent = 'Retry';
  retryButton.setAttribute('aria-label', 'Retry loading virtual coins');
  retryButton.style.cssText =
    'margin:4px;padding:4px 9px;border:1px solid #d2a449;border-radius:8px;background:#17120b;color:#ffe5a0;font:inherit;cursor:pointer';
  retryButton.addEventListener('click', () => { void sync(); });
  wallet.appendChild(retryButton);
}

async function sync() {
  if (walletSyncInFlight) return null;
  walletSyncInFlight = true;
  try {
    return await refreshWallet();
  } catch (error) {
    showWalletError();
    console.error(error.message);
    return null;
  } finally {
    walletSyncInFlight = false;
  }
}

window.s999RefreshWallet = sync;
const isHomePage = document.body.classList.contains('s999-home');
window.s999WalletReady = isHomePage
  ? Promise.resolve(null)
  : sync();
window.addEventListener('focus', () => {
  if (!isHomePage || !document.getElementById('lobbyApp')?.classList.contains('hidden')) sync();
});
window.setInterval(() => {
  if (!isHomePage || !document.getElementById('lobbyApp')?.classList.contains('hidden')) sync();
}, 30_000);
