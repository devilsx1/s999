(() => {
  const $ = id => document.getElementById(id);
  const authScreen = $('authScreen');
  const lobby = $('lobbyApp');
  const loginScene = $('loginScene');
  const registerScene = $('registerScene');
  const loginForm = $('loginForm');
  const registerForm = $('registerForm');
  const notice = $('authNotice');
  let vipRewardsLoading = false;
  const rewardNumberFormat = new Intl.NumberFormat(undefined, {
    maximumFractionDigits: 0
  });

  async function apiRequest(url, options={}) {
    const headers = {...(options.headers || {})};
    if (options.body) headers['Content-Type'] = 'application/json';
    const response = await fetch(url, {...options, headers, credentials:'same-origin', cache:'no-store'});
    let data = {};
    try { data = await response.json(); } catch {}
    if (!response.ok) throw new Error(data.error || 'Request failed. Please try again.');
    return data;
  }

  function renderVipRewards(data) {
    const summary = $('vipRewardsSummary');
    const tiers = Array.isArray(data.tiers) ? data.tiers : [];
    const claimableCount = tiers.filter(tier => tier.status === 'available').length;
    if (summary) {
      summary.textContent = `VIP ${data.vipLevel} · ${claimableCount} ready`;
    }

    tiers.forEach(tier => {
      const card = document.querySelector(`[data-vip-tier="${tier.level}"]`);
      const button = card?.querySelector('[data-claim-vip-level]');
      if (!card || !button) return;

      card.dataset.rewardStatus = tier.status;
      button.dataset.rewardStatus = tier.status;
      button.disabled = tier.status !== 'available';
      if (tier.status === 'available') {
        button.textContent = '🎁 Claim';
        button.setAttribute('aria-label', `Claim VIP ${tier.level} treasure reward`);
      } else if (tier.status === 'claimed') {
        button.textContent = '✓ Claimed';
        button.setAttribute('aria-label', `VIP ${tier.level} treasure reward claimed`);
      } else {
        button.textContent = '🔒 Locked';
        button.setAttribute('aria-label', `VIP ${tier.level} reward locked`);
      }
    });
  }

  async function loadVipRewards({silent=false}={}) {
    if (vipRewardsLoading || !$('vipRewards')) return;
    vipRewardsLoading = true;
    try {
      const data = await apiRequest('/api/vip/rewards');
      renderVipRewards(data);
    } catch (error) {
      if (!silent) {
        const summary = $('vipRewardsSummary');
        if (summary) summary.textContent = 'VIP rewards unavailable';
        const status = $('vipRewardNotice');
        if (status) status.textContent = error.message;
      }
    } finally {
      vipRewardsLoading = false;
    }
  }

  function showLobby(name){
    authScreen.classList.add('hidden'); lobby.classList.remove('hidden');
    $('welcomeName').textContent = name || 'Player';
    document.title = 'S999 — Lobby';
    window.scrollTo(0, 0);
    window.s999RefreshWallet?.();
    void loadVipRewards();
    if (window.location.hash === '#vipRewards') {
      window.setTimeout(() => $('vipRewards')?.scrollIntoView({behavior:'smooth', block:'start'}), 0);
    }
  }
  function showAuth(scene='login'){
    const isRegister = scene === 'register';
    authScreen.classList.remove('hidden');
    lobby.classList.add('hidden');
    loginScene.classList.toggle('hidden', isRegister);
    registerScene.classList.toggle('hidden', !isRegister);
    $('showLogin').classList.toggle('active', !isRegister);
    $('showRegister').classList.toggle('active', isRegister);
    notice.textContent = '';
    document.title = isRegister ? 'S999 — Register' : 'S999 — Login';
    window.scrollTo(0, 0);
  }

  const requestedScene = new URLSearchParams(window.location.search).get('scene') === 'register' ? 'register' : 'login';
  showAuth(requestedScene);
  apiRequest('/api/auth/me').then(result=>{
    if(result.authenticated) showLobby(result.user.fullName);
  }).catch(error=>{
    notice.textContent=error.message || 'Could not connect to your account.';
  });

  $('showLogin').addEventListener('click',()=>showAuth('login'));
  $('showRegister').addEventListener('click',()=>showAuth('register'));
  $('backToLogin').addEventListener('click',()=>showAuth('login'));
  document.querySelectorAll('[data-show-login]').forEach(link=>link.addEventListener('click',()=>showAuth('login')));
  document.querySelectorAll('[data-show-register]').forEach(link=>link.addEventListener('click',e=>{
    e.preventDefault();
    showAuth('register');
  }));
  document.querySelectorAll('[data-requires-login]').forEach(link=>link.addEventListener('click',e=>{
    e.preventDefault();
    showAuth('login');
    notice.textContent='Log in to open the games lobby.';
  }));
  $('forgotPassword').addEventListener('click',()=>{
    notice.textContent='Password reset is not available yet. Contact support for help.';
  });
  document.querySelectorAll('[data-social]').forEach(button=>button.addEventListener('click',()=>{
    notice.textContent=`${button.dataset.social} sign-in isn't connected.`;
  }));
  document.querySelectorAll('[data-toggle-password]').forEach(button=>button.addEventListener('click',()=>{
    const input=$(button.dataset.togglePassword);
    const isHidden=input.type==='password';
    input.type=isHidden?'text':'password';
    button.setAttribute('aria-label',isHidden?'Hide password':'Show password');
  }));

  registerForm.addEventListener('submit',async e=>{
    e.preventDefault();
    const fullName=$('registerName').value.trim();
    const email=$('registerEmail').value.trim().toLowerCase();
    const phone=$('registerPhone').value.trim();
    const password=$('registerPass').value;
    const confirm=$('registerConfirm').value;
    if(fullName.length<2){notice.textContent='Enter your full name.';return}
    if(password.length<8){notice.textContent='Password must have at least 8 characters.';return}
    if(password!==confirm){notice.textContent='The passwords do not match.';return}
    notice.textContent='Creating your account…';
    try {
      const result=await apiRequest('/api/auth/register',{
        method:'POST',
        body:JSON.stringify({fullName,email,phone,password,rememberMe:true})
      });
      registerForm.reset();
      notice.textContent='';
      showLobby(result.user.fullName);
    } catch(error) {
      notice.textContent=error.message;
    }
  });
  loginForm.addEventListener('submit',async e=>{
    e.preventDefault();
    const username=$('loginUser').value.trim();
    const password=$('loginPass').value;
    notice.textContent='Signing in…';
    try {
      const result=await apiRequest('/api/auth/login',{
        method:'POST',
        body:JSON.stringify({username,password,rememberMe:$('rememberMe').checked})
      });
      loginForm.reset();
      notice.textContent='';
      showLobby(result.user.fullName);
    } catch(error) {
      notice.textContent=error.message;
    }
  });
  document.querySelectorAll('#logoutButton').forEach(button=>button.addEventListener('click',async()=>{
    try {
      await apiRequest('/api/auth/logout',{method:'POST'});
      loginForm.reset();
      registerForm.reset();
      showAuth('login');
      notice.textContent='You have logged out.';
    } catch(error) {
      notice.textContent=error.message;
    }
  }));
  document.querySelector('.vip-tier-grid')?.addEventListener('click', async event => {
    const button = event.target.closest('[data-claim-vip-level]');
    if (!button || button.disabled) return;

    const level = Number(button.dataset.claimVipLevel);
    const rewardStatus = $('vipRewardNotice');
    button.disabled = true;
    button.textContent = 'Opening…';
    if (rewardStatus) rewardStatus.textContent = '';
    try {
      const result = await apiRequest(`/api/vip/rewards/${level}/claim`, {method:'POST'});
      await Promise.allSettled([
        loadVipRewards({silent:true}),
        Promise.resolve().then(() => window.s999RefreshWallet?.())
      ]);
      if (rewardStatus) {
        rewardStatus.textContent = result.alreadyClaimed
          ? `VIP ${level} treasure was already claimed.`
          : `VIP ${level} treasure claimed: +${rewardNumberFormat.format(result.amount)} Demo Coins.`;
      }
    } catch (error) {
      await loadVipRewards({silent:true});
      if (rewardStatus) rewardStatus.textContent = error.message;
    }
  });
  window.setInterval(() => {
    if (!document.hidden && !lobby.classList.contains('hidden')) {
      void loadVipRewards({silent:true});
    }
  }, 5000);
  document.querySelectorAll('[data-filter]').forEach(button=>button.addEventListener('click',()=>{
    const filter=button.dataset.filter;
    document.querySelectorAll('.category').forEach(b=>b.classList.toggle('active',b===button));
    document.querySelectorAll('.game').forEach(game=>game.style.display=(filter==='All'||game.dataset.cat===filter)?'flex':'none');
  }));
  const showAllButton=document.querySelector('[data-show-all]');
  showAllButton.addEventListener('click',()=>{
    document.querySelectorAll('.category').forEach(b=>b.classList.toggle('active',b.dataset.filter==='All'));
    document.querySelectorAll('.game').forEach(game=>game.style.display='flex');
  });
  document.querySelectorAll('.bottom-nav a[href="#gameGrid"], .lobby-links a[href="#gameGrid"]').forEach(a=>a.addEventListener('click',e=>{
    e.preventDefault();
    $('gameGrid').scrollIntoView({behavior:'smooth'});
  }));
})();
