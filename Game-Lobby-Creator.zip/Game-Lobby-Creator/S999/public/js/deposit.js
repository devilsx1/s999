
(() => {
  const $ = id => document.getElementById(id);

  const form = $('depositRequestForm');
  const notice = $('depositNotice');
  const requestList = $('depositRequestList');

  let loading = false;
  let submitting = false;

  async function api(url, options = {}) {
    const headers = { ...(options.headers || {}) };

    if (options.body) {
      headers['Content-Type'] = 'application/json';
    }

    const response = await fetch(url, {
      ...options,
      headers,
      credentials: 'same-origin',
      cache: 'no-store'
    });

    let data = {};

    try {
      data = await response.json();
    } catch {}

    if (response.status === 401) {
      window.location.replace('/?scene=login');
      throw new Error('Please log in to continue.');
    }

    if (!response.ok) {
      throw new Error(data.error || 'Request failed.');
    }

    return data;
  }

  function addDetail(container, label, value) {
    if (value === undefined || value === null || value === '') {
      return;
    }

    const detail = document.createElement('small');
    detail.textContent = `${label}: ${value}`;

    container.append(
      document.createElement('br'),
      detail
    );
  }

  function renderRequests(requests) {
    requestList.replaceChildren();

    if (!Array.isArray(requests) || !requests.length) {
      const empty = document.createElement('p');

      empty.className = 'empty-state';
      empty.textContent = 'No requests yet.';

      requestList.append(empty);
      return;
    }

    for (const request of requests) {
      const item = document.createElement('article');
      item.className = 'request-item';

      const info = document.createElement('div');

      const amount = document.createElement('strong');

      amount.textContent =
        `${Number(request.amount).toLocaleString()} PKR`;

      info.append(amount);

      if (request.createdAt) {
        const date = new Date(request.createdAt);

        if (!Number.isNaN(date.getTime())) {
          addDetail(
            info,
            'Date',
            new Intl.DateTimeFormat(undefined, {
              dateStyle: 'medium',
              timeStyle: 'short'
            }).format(date)
          );
        }
      }

      addDetail(info, 'Sender Name', request.senderName);
      addDetail(info, 'Sender Number', request.senderNumber);
      addDetail(info, 'TRX ID', request.trxId);

      const status = document.createElement('span');
      const validStatuses = [
        'pending',
        'approved',
        'rejected'
      ];

      const requestStatus = String(
        request.status || 'pending'
      ).toLowerCase();

      status.className =
        'status-pill status-' +
        (validStatuses.includes(requestStatus)
          ? requestStatus
          : 'pending');

      status.textContent = requestStatus;

      item.append(info, status);
      requestList.append(item);
    }
  }

  async function loadPage() {
    if (loading || submitting) return;

    loading = true;

    try {
      const [wallet, result] = await Promise.all([
        api('/api/wallet'),
        api('/api/deposit-requests')
      ]);

      const balance = $('accountBalance');

      if (balance) {
        balance.textContent =
          Number(wallet.demoCoins || 0).toLocaleString();
      }

      renderRequests(result.requests);

    } catch (error) {
      notice.textContent = error.message;
    } finally {
      loading = false;
    }
  }

  form.addEventListener('submit', async event => {
    event.preventDefault();

    if (submitting) return;
    if (!form.reportValidity()) return;

    const button = form.querySelector(
      'button[type="submit"]'
    );

    const amount = Number($('requestAmount').value);
    const senderNumber = $('senderNumber').value.trim();
    const senderName = $('senderName').value.trim();
    const trxId = $('trxId').value.trim();

    if (!Number.isInteger(amount) ||
        amount < 1 ||
        amount > 1000000) {
      notice.textContent =
        'Enter a valid deposit amount.';
      return;
    }

    if (!senderNumber || !senderName || !trxId) {
      notice.textContent =
        'All payment details are required.';
      return;
    }

    submitting = true;
    button.disabled = true;

    notice.textContent = 'Submitting deposit request…';

    try {
      await api('/api/deposit-requests', {
        method: 'POST',
        body: JSON.stringify({
          amount,
          senderNumber,
          senderName,
          trxId
        })
      });

      form.reset();

      notice.textContent =
        'Deposit request submitted successfully. ' +
        'Waiting for admin approval.';

    } catch (error) {
      notice.textContent = error.message;
    } finally {
      submitting = false;
      button.disabled = false;
    }

    await loadPage();
  });

  loadPage();

  window.addEventListener('focus', loadPage);

  window.setInterval(() => {
    if (!document.hidden) loadPage();
  }, 15000);
})();
