(() => {
  const transactionList = document.getElementById("transactionList");
  const transactionToggle = document.getElementById("transactionToggle");
  const notice = document.getElementById("walletNotice");
  const filterButtons = [...document.querySelectorAll("[data-history-filter]")];
  const paymentButtons = [...document.querySelectorAll("[data-payment-method]")];
  const withdrawalButton = document.getElementById("withdrawUnavailable");
  const accountDialog = document.getElementById("accountDialog");
  const accountForm = document.getElementById("accountForm");
  const accountPhone = document.getElementById("accountPhone");
  const accountFormNotice = document.getElementById("accountFormNotice");
  const withdrawDialog = document.getElementById("withdrawDialog");
  const withdrawForm = document.getElementById("withdrawForm");
  const withdrawProvider = document.getElementById("withdrawProvider");
  const withdrawAmount = document.getElementById("withdrawAmount");
  const withdrawBalance = document.getElementById("withdrawBalance");
  const withdrawFormNotice = document.getElementById("withdrawFormNotice");
  const submitWithdrawal = document.getElementById("submitWithdrawal");

  const providerLabels = {
    easypaisa: "EasyPaisa",
    jazzcash: "JazzCash",
  };
  const accounts = new Map();
  let transactions = [];
  let currentBalance = 0;
  let activeFilter = "all";
  let activeProvider = "";
  let expanded = false;

  const formatCoins = value => {
    const amount = Number(value);
    return Number.isFinite(amount)
      ? amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })
      : "0.00";
  };

  async function api(url, options = {}) {
    const headers = { ...(options.headers || {}) };
    if (options.body) headers["Content-Type"] = "application/json";
    const response = await fetch(url, {
      ...options,
      headers,
      credentials: "same-origin",
      cache: "no-store",
    });
    let data = {};
    try {
      data = await response.json();
    } catch {
      // Keep the server's status as the source of truth for non-JSON errors.
    }
    if (response.status === 401) {
      window.location.replace("/?scene=login");
      throw new Error("Please log in to continue.");
    }
    if (!response.ok) throw new Error(data.error || "Request failed.");
    return data;
  }

  function categoryFor(item) {
    const label = String(item.label || "").toLowerCase();
    if (label.includes("withdrawal")) return "withdrawal";
    if (label.includes("approved demo coin request") || label.includes("deposit")) {
      return "deposit";
    }
    return "activity";
  }

  function filteredTransactions() {
    return activeFilter === "all"
      ? transactions
      : transactions.filter(item => categoryFor(item) === activeFilter);
  }

  function showEmptyState(message, detail) {
    const empty = document.createElement("div");
    empty.className = "transaction-empty";

    const icon = document.createElement("span");
    icon.className = "empty-icon";
    icon.setAttribute("aria-hidden", "true");
    icon.innerHTML = '<svg viewBox="0 0 56 56"><path d="M12 8h26v35H12z"/><path d="M18 16h14M18 22h14M18 28h8"/><circle cx="38" cy="37" r="8"/><path d="m44 43 5 5M38 33v8M34 37h8"/></svg><i>✦</i>';

    const title = document.createElement("strong");
    title.textContent = message;
    const subtitle = document.createElement("span");
    subtitle.textContent = detail;
    empty.append(icon, title, subtitle);
    transactionList.replaceChildren(empty);
  }

  function renderTransactions() {
    const visibleTransactions = filteredTransactions();
    transactionToggle.hidden = visibleTransactions.length <= 5;
    transactionToggle.textContent = expanded ? "Show Less ›" : "View All ›";

    if (!visibleTransactions.length) {
      const title = activeFilter === "withdrawal"
        ? "No withdrawals yet"
        : activeFilter === "deposit"
          ? "No deposits yet"
          : "No transactions yet";
      showEmptyState(title, "Your Demo Coin activity will appear here.");
      return;
    }

    const entries = expanded ? visibleTransactions : visibleTransactions.slice(0, 5);
    const fragment = document.createDocumentFragment();
    for (const item of entries) {
      const row = document.createElement("article");
      row.className = "transaction-row";

      const type = categoryFor(item);
      const icon = document.createElement("span");
      icon.className = "transaction-icon";
      icon.setAttribute("aria-hidden", "true");
      icon.textContent = type === "deposit" ? "↓" : type === "withdrawal" ? "↑" : "✦";

      const copy = document.createElement("span");
      copy.className = "transaction-copy";
      const label = document.createElement("strong");
      label.textContent = String(item.label || "Demo Coin activity");
      const date = document.createElement("small");
      const dateValue = new Date(item.createdAt);
      date.textContent = Number.isNaN(dateValue.getTime())
        ? "Demo Coin activity"
        : new Intl.DateTimeFormat(undefined, {
            dateStyle: "medium",
            timeStyle: "short",
          }).format(dateValue);
      copy.append(label, date);

      const amount = document.createElement("span");
      const lowerLabel = String(item.label || "").toLowerCase();
      const outgoing = lowerLabel.includes(" bet ")
        || (lowerLabel.includes("withdrawal") && !lowerLabel.includes("refunded"));
      amount.className = `transaction-amount${outgoing ? " is-outgoing" : ""}`;
      amount.textContent = `${outgoing ? "−" : "+"}${Number(item.amount || 0).toLocaleString()} Coins`;

      row.append(icon, copy, amount);
      fragment.append(row);
    }
    transactionList.replaceChildren(fragment);
  }

  function updateWallet(data) {
    if (!data || !Number.isFinite(Number(data.demoCoins))) return;
    currentBalance = Number(data.demoCoins);
    document.querySelectorAll("[data-coins]").forEach(element => {
      element.textContent = formatCoins(currentBalance);
    });
    transactions = Array.isArray(data.activity) ? data.activity : [];
    renderTransactions();
    updateWithdrawControls();
  }

  function maskPhone(value) {
    const digits = String(value || "").replace(/\D/g, "");
    if (digits.length < 7) return "Linked";
    return `+${digits.slice(0, 2)} ${digits.slice(2, 4)}•••••${digits.slice(-2)}`;
  }

  function updateAccountCards() {
    document.querySelectorAll("[data-account-status]").forEach(status => {
      const provider = status.dataset.accountStatus;
      const account = accounts.get(provider);
      status.textContent = account
        ? `Linked · ${maskPhone(account.phoneNumber)}`
        : "No number linked";
    });
  }

  function updateWithdrawControls() {
    const selected = withdrawProvider.value;
    withdrawProvider.replaceChildren();

    for (const provider of ["easypaisa", "jazzcash"]) {
      const account = accounts.get(provider);
      if (!account) continue;
      const option = document.createElement("option");
      option.value = provider;
      option.textContent = `${providerLabels[provider]} · ${maskPhone(account.phoneNumber)}`;
      withdrawProvider.append(option);
    }

    const hasAccounts = withdrawProvider.options.length > 0;
    withdrawProvider.disabled = !hasAccounts;
    submitWithdrawal.disabled = !hasAccounts || currentBalance < 1;
    if (hasAccounts && [...withdrawProvider.options].some(option => option.value === selected)) {
      withdrawProvider.value = selected;
    }

    withdrawBalance.textContent = currentBalance.toLocaleString();
    withdrawAmount.max = String(Math.min(1_000_000, currentBalance));
    if (currentBalance < 1) {
      withdrawFormNotice.textContent = "You need Demo Coins in your balance before requesting a withdrawal.";
    } else if (!hasAccounts) {
      withdrawFormNotice.textContent = "Link an EasyPaisa or JazzCash number first.";
    }
  }

  async function loadAccounts() {
    try {
      const result = await api("/api/wallet/accounts");
      accounts.clear();
      for (const account of result.accounts || []) {
        accounts.set(account.provider, account);
      }
      updateAccountCards();
      updateWithdrawControls();
    } catch (error) {
      announce(error.message);
    }
  }

  function announce(message) {
    notice.textContent = message;
    notice.classList.add("is-visible");
  }

  function openAccountDialog(provider) {
    activeProvider = provider.toLowerCase();
    const current = accounts.get(activeProvider);
    document.getElementById("accountDialogTitle").textContent = `Link ${providerLabels[activeProvider]}`;
    accountPhone.value = current?.phoneNumber || "";
    accountFormNotice.textContent = "";
    accountDialog.showModal();
    accountPhone.focus();
  }

  paymentButtons.forEach(button => {
    button.addEventListener("click", () => {
      openAccountDialog(button.dataset.paymentMethod || "easypaisa");
    });
  });

  accountForm.addEventListener("submit", async event => {
    event.preventDefault();
    const saveButton = accountForm.querySelector('button[type="submit"]');
    saveButton.disabled = true;
    accountFormNotice.textContent = "Saving number…";
    try {
      const result = await api(`/api/wallet/accounts/${activeProvider}`, {
        method: "PUT",
        body: JSON.stringify({ phoneNumber: accountPhone.value.trim() }),
      });
      accounts.set(result.account.provider, result.account);
      updateAccountCards();
      updateWithdrawControls();
      accountDialog.close();
      announce(`${providerLabels[activeProvider]} number linked for Demo Coin requests.`);
    } catch (error) {
      accountFormNotice.textContent = error.message;
    } finally {
      saveButton.disabled = false;
    }
  });

  withdrawalButton.addEventListener("click", () => {
    withdrawFormNotice.textContent = "";
    updateWithdrawControls();
    withdrawDialog.showModal();
  });

  withdrawForm.addEventListener("submit", async event => {
    event.preventDefault();
    submitWithdrawal.disabled = true;
    withdrawFormNotice.textContent = "Sending request…";
    try {
      const result = await api("/api/withdrawal-requests", {
        method: "POST",
        body: JSON.stringify({
          provider: withdrawProvider.value,
          amount: Number(withdrawAmount.value),
        }),
      });
      withdrawForm.reset();
      withdrawDialog.close();
      announce("Demo Coin withdrawal request sent to the admin. No cash payment will be made.");
      if (Number.isFinite(Number(result.demoCoins))) {
        currentBalance = Number(result.demoCoins);
        document.querySelectorAll("[data-coins]").forEach(element => {
          element.textContent = formatCoins(currentBalance);
        });
      }
      if (typeof window.s999RefreshWallet === "function") {
        await window.s999RefreshWallet();
      }
    } catch (error) {
      withdrawFormNotice.textContent = error.message;
      submitWithdrawal.disabled = false;
    }
  });

  document.querySelectorAll("[data-close-dialog]").forEach(button => {
    button.addEventListener("click", () => {
      document.getElementById(button.dataset.closeDialog)?.close();
    });
  });

  filterButtons.forEach(button => {
    button.addEventListener("click", () => {
      activeFilter = button.dataset.historyFilter || "all";
      expanded = false;
      filterButtons.forEach(tab => {
        const isActive = tab === button;
        tab.classList.toggle("is-active", isActive);
        tab.setAttribute("aria-selected", String(isActive));
      });
      renderTransactions();
    });
  });

  transactionToggle.addEventListener("click", () => {
    expanded = !expanded;
    renderTransactions();
  });

  window.addEventListener("s999:wallet-updated", event => updateWallet(event.detail));
  if (window.s999WalletReady && typeof window.s999WalletReady.then === "function") {
    window.s999WalletReady.then(data => {
      updateWallet(data);
      void loadAccounts();
    });
  } else {
    void loadAccounts();
  }
})();
