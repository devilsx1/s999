(() => {
  const VIP_THRESHOLDS = [
    1_000, 5_000, 10_000, 20_000, 50_000,
    100_000, 500_000, 1_000_000, 1_000_000, 2_000_000,
  ];
  const VIP_PERCENTAGES = [1, 0, 2, 0, 3, 0, 0, 0, 0, 5];
  const coinFormat = new Intl.NumberFormat(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
  const wholeCoinFormat = new Intl.NumberFormat(undefined, {
    maximumFractionDigits: 0,
  });

  const byId = id => document.getElementById(id);
  const setText = (id, value) => {
    const element = byId(id);
    if (element) element.textContent = value;
  };
  let avatarSetupPlayerId = "";
  let profileLoadInProgress = false;

  function announce(message) {
    const status = byId("profileToast");
    if (!status) return;
    status.textContent = message;
    status.classList.add("is-visible");
    window.clearTimeout(announce.timeout);
    announce.timeout = window.setTimeout(() => {
      status.classList.remove("is-visible");
    }, 2800);
  }

  async function api(url, options = {}) {
    const response = await fetch(url, {
      ...options,
      credentials: "same-origin",
      cache: "no-store",
      headers: {
        ...(options.body ? { "Content-Type": "application/json" } : {}),
        ...(options.headers || {}),
      },
    });
    let payload = {};
    try {
      payload = await response.json();
    } catch {
      // The HTTP response still provides the authoritative failure status.
    }
    if (response.status === 401) {
      window.location.replace("/?scene=login");
      throw new Error("Please log in to continue.");
    }
    if (!response.ok) {
      throw new Error(payload.error || "Could not load profile details.");
    }
    return payload;
  }

  function updateVipProgress(totalDeposit) {
    const deposit = Number.isFinite(totalDeposit) ? Math.max(0, totalDeposit) : 0;
    let currentLevel = 0;
    for (let index = 0; index < VIP_THRESHOLDS.length; index += 1) {
      if (deposit >= VIP_THRESHOLDS[index]) currentLevel = index + 1;
      else break;
    }

    const nextThreshold = VIP_THRESHOLDS[currentLevel];
    let progress = 100;
    if (currentLevel < VIP_THRESHOLDS.length) {
      const currentThreshold = currentLevel === 0 ? 0 : VIP_THRESHOLDS[currentLevel - 1];
      const tierSpan = nextThreshold - currentThreshold;
      const tierProgress = tierSpan > 0
        ? Math.max(0, Math.min(1, (deposit - currentThreshold) / tierSpan))
        : 0;
      progress = ((currentLevel + tierProgress) / VIP_THRESHOLDS.length) * 100;
    }

    setText("currentVip", `VIP ${currentLevel}`);
    setText("profileVipBadge", `VIP ${currentLevel}`);
    setText("vipCurrentDeposit", coinFormat.format(deposit));

    const progressElement = byId("vipProgress");
    if (progressElement) {
      const fill = progressElement.querySelector(".progress-fill");
      const marker = progressElement.querySelector(".progress-current");
      if (fill) fill.style.width = `${progress}%`;
      if (marker) marker.style.left = `${progress}%`;
      progressElement.setAttribute("aria-valuenow", progress.toFixed(1));
      const progressDescription = currentLevel === VIP_THRESHOLDS.length
        ? `${wholeCoinFormat.format(deposit)} Demo Coins. VIP ${currentLevel} maximum level reached.`
        : `${wholeCoinFormat.format(deposit)} Demo Coins. ${wholeCoinFormat.format(Math.max(0, nextThreshold - deposit))} more to VIP ${currentLevel + 1}.`;
      progressElement.setAttribute(
        "aria-valuetext",
        progressDescription,
      );
    }

    document.querySelectorAll("[data-vip-level]").forEach(element => {
      const level = Number(element.dataset.vipLevel);
      element.classList.toggle("is-current", level === currentLevel);
      element.classList.toggle("is-complete", level < currentLevel);
    });

    const currentThresholdElement = document.querySelector("[data-vip-current-threshold]");
    if (currentThresholdElement) {
      if (currentLevel === VIP_THRESHOLDS.length) {
        currentThresholdElement.closest(".next-threshold").textContent = "Max level";
      } else {
        currentThresholdElement.textContent = wholeCoinFormat.format(nextThreshold);
      }
    }

    VIP_PERCENTAGES.forEach((percentage, index) => {
      document.querySelectorAll(`[data-vip-bonus="${index + 1}"]`).forEach(percentElement => {
        percentElement.textContent = percentage ? `${percentage}%` : "None";
      });
    });
  }

  function updateProfile(profile) {
    const rawId = String(profile.id ?? "");
    const playerId = rawId.length < 8 ? rawId.padStart(8, "0") : rawId;
    const name = String(profile.fullName || "Player");
    const balance = Number(profile.demoCoins);
    const totalDeposit = Number(profile.totalDeposit);
    const totalBonus = Number(profile.totalBonus);
    const shareBonus = Number(profile.shareBonus ?? 0);
    const gamesPlayed = Number(profile.gamesPlayed);

    setText("profileName", name);
    setText("profileId", playerId || "—");
    setText("profileBalance", Number.isFinite(balance) ? wholeCoinFormat.format(balance) : "0");
    setText("profileBalanceInline", Number.isFinite(balance) ? coinFormat.format(balance) : "0.00");
    setText("totalDeposit", Number.isFinite(totalDeposit) ? coinFormat.format(totalDeposit) : "0.00");
    setText("totalBonus", Number.isFinite(totalBonus) ? coinFormat.format(totalBonus) : "0.00");
    setText("shareBonusAmount", Number.isFinite(shareBonus) ? coinFormat.format(shareBonus) : "0.00");
    setText("gamesPlayed", Number.isFinite(gamesPlayed) ? wholeCoinFormat.format(gamesPlayed) : "0");

    document.querySelectorAll("[data-coins]").forEach(element => {
      element.textContent = Number.isFinite(balance) ? wholeCoinFormat.format(balance) : "0";
    });
    updateVipProgress(Number.isFinite(totalDeposit) ? totalDeposit : 0);
    setupAvatar(playerId);
  }

  async function copyText(value, successMessage) {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(value);
      } else {
        const field = document.createElement("textarea");
        field.value = value;
        field.setAttribute("readonly", "");
        field.style.position = "fixed";
        field.style.opacity = "0";
        document.body.append(field);
        field.select();
        const copied = document.execCommand("copy");
        field.remove();
        if (!copied) throw new Error("Copy is not available in this browser.");
      }
      announce(successMessage);
    } catch {
      announce("Copy is not available in this browser.");
    }
  }

  function setupAvatar(playerId) {
    const trigger = byId("avatarUpload");
    const input = byId("avatarFile");
    const image = byId("profileAvatarImage");
    if (!trigger || !input || !image || !playerId) return;
    if (avatarSetupPlayerId === playerId) return;
    avatarSetupPlayerId = playerId;
    const storageKey = `s999-profile-avatar:${playerId}`;

    let savedAvatar = "";
    try {
      savedAvatar = localStorage.getItem(storageKey) || "";
    } catch {
      // The account page remains usable when local storage is unavailable.
    }
    const showAvatar = source => {
      image.src = source;
      image.hidden = false;
    };
    if (savedAvatar.startsWith("data:image/")) showAvatar(savedAvatar);

    trigger.addEventListener("click", () => input.click());
    input.addEventListener("change", () => {
      const file = input.files?.[0];
      if (!file) return;
      if (!file.type.startsWith("image/") || file.size > 1_500_000) {
        announce("Choose an image smaller than 1.5 MB.");
        input.value = "";
        return;
      }

      const reader = new FileReader();
      reader.addEventListener("load", () => {
        if (typeof reader.result !== "string") return;
        showAvatar(reader.result);
        try {
          localStorage.setItem(storageKey, reader.result);
          announce("Profile photo updated on this device.");
        } catch {
          announce("Photo preview updated for this visit only.");
        }
      });
      reader.readAsDataURL(file);
    });
  }

  function setupInteractions() {
    byId("copyProfileId")?.addEventListener("click", () => {
      copyText(byId("profileId")?.textContent || "", "Player ID copied.");
    });
    [byId("copyProfileLink"), byId("copyProfileLinkAlt")].forEach(button => {
      button?.addEventListener("click", () => {
        copyText(window.location.href, "Profile link copied.");
      });
    });
    byId("shareProfile")?.addEventListener("click", async () => {
      const shareData = {
        title: "S999 Profile",
        text: `S999 profile for ${byId("profileName")?.textContent || "Player"}`,
        url: window.location.href,
      };
      if (navigator.share) {
        try {
          await navigator.share(shareData);
        } catch (error) {
          if (error.name !== "AbortError") announce("Sharing is not available right now.");
        }
      } else {
        await copyText(shareData.url, "Profile link copied.");
      }
    });
    byId("shareMoreButton")?.addEventListener("click", () => {
      byId("shareProfile")?.click();
    });

    document.querySelectorAll("#logoutButtonTop").forEach(button => {
      button.addEventListener("click", async () => {
        button.disabled = true;
        try {
          await api("/api/auth/logout", { method: "POST" });
          window.location.replace("/?scene=login");
        } catch (error) {
          button.disabled = false;
          announce(error.message);
        }
      });
    });

    byId("profileSettings")?.addEventListener("click", () => {
      const dialog = byId("profileSettingsDialog");
      if (dialog?.showModal) dialog.showModal();
      else announce("Profile settings are not available right now.");
    });

    document.querySelectorAll("[data-close-profile-dialog]").forEach(button => {
      button.addEventListener("click", () => byId("profileSettingsDialog")?.close());
    });

  }

  async function loadProfile({ silent = false } = {}) {
    if (profileLoadInProgress) return;
    profileLoadInProgress = true;
    try {
      const profile = await api("/api/profile/summary");
      updateProfile(profile);
    } catch (error) {
      if (!silent && error.message !== "Please log in to continue.") announce(error.message);
    } finally {
      profileLoadInProgress = false;
    }
  }

  setupInteractions();
  void loadProfile();
  window.setInterval(() => {
    if (!document.hidden) void loadProfile({ silent: true });
  }, 5000);
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) void loadProfile({ silent: true });
  });
})();
