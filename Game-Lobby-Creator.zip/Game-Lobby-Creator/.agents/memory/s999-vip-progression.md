---
name: S999 VIP progression
description: Product rule for when player VIP level and progress advance.
---

S999 VIP progression is based on the cumulative amount of admin-approved Demo Coin deposits only. Pending and rejected requests do not count. An open profile should refresh automatically after approval and show the new level and progress. Each reached VIP tier has a permanent, one-time Demo Coin treasure reward; eligible earlier tiers remain claimable.

**Why:** the user explicitly requested VIP level/progress and treasure rewards to advance with admin-approved deposits, while the existing rewards screen describes each chest as a one-time claim.

**How to apply:** keep accepted-deposit ledger entries as the source of truth; compute VIP from their lifetime sum, allow each eligible chest to be claimed once, and refresh the visible profile while it remains open. Keep all balances clearly labeled as non-cash Demo Coins.
