---
name: S999 Dragon Tiger rounds
description: Product requirement for autonomous, shared Dragon Tiger rounds.
---

Dragon Tiger rounds run on the server, advance without an open browser, and show the same round and result to all players. Card results are randomly drawn on the server, and the game uses Demo Coins only. Betting stays open for 12 seconds, cards reveal immediately at the cutoff, and the result remains visible for 3 seconds before the next round.

Tie bets return 9× the stake in total when Tie wins, including the original stake.

Bet sizes range from 20 to 20,000 Demo Coins. Quick chips are 20, 50, 100, 200, 500, 1,000, 2,000, 5,000, 10,000, and 20,000. Plus and minus adjust by the selected chip amount.

**Why:** The user asked for automatic rounds that do not stop when players leave the page, shared through one server, while keeping other game screens unchanged. They specified the 12-second betting window, immediate card reveal, 3-second result hold, stake bounds, and chip-step controls.

**How to apply:** Keep rounds server-driven and shared, draw cards randomly on the server, and use Demo Coins only. Preserve the timing, stake bounds, increment behavior, and 9× Tie return. Do not let browser activity control round progression.
