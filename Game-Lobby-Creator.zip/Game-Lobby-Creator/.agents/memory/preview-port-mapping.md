---
name: Preview port mapping
description: Diagnose Replit domain 404s when the local app server is healthy.
---

When the app responds on its local port but the Replit domain returns 404, inspect `.replit` port mappings before changing application code. An old mapping for external port 80 can remain after removing an artifact and keep routing the root domain to an inactive local port. Map external port 80 to the active web app port, then restart the workflow once. Direct `.replit` edits are blocked: write the full updated TOML to an in-workspace temporary file, then call `verifyAndReplaceDotReplit({ tempFilePath })`. After it reports success, re-read `.replit` and curl the Replit domain to confirm the mapping actually took effect; do not rely on the success response alone.

**Why:** A stale root mapping caused the Replit domain to return 404 even though the S999 server was responding normally on its configured port. The first config-replacement call reported success but the file still showed the stale mapping; a second call followed by immediate readback confirmed the update.

**How to apply:** Compare the configured `[[ports]]` entries with the active workflow port whenever local curl succeeds but the proxied domain does not. Verify the updated file and proxied route after replacing the config and restarting.
