---
name: S999 numeric round ordering
description: Prevent lexical ordering from breaking Dragon Tiger round timing.
---

When selecting the latest Dragon Tiger round, sort by the qualified numeric source column (for example, `dragon_tiger_rounds.id DESC`) rather than an `id::text AS id` select-list alias.

**Why:** PostgreSQL sorts by the aliased text value in `ORDER BY id`; after round IDs passed 9999, that selected an old round lexically, rejected new bets, and caused the timer to create empty rounds repeatedly.

**How to apply:** Keep latest-round sorting numeric in both engine and bet-placement queries, and test with IDs above 9999.
