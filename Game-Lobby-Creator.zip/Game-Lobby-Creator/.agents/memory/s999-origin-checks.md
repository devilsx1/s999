---
name: S999 origin checks
description: Keep the app's write-request origin guard compatible with Replit-hosted domains without permitting arbitrary cross-site requests.
---

For S999 write requests, compare the browser Origin against the exact forwarded/request host and explicitly configured Replit domains. Replit may omit the externally mapped port from `X-Forwarded-Host`; when the request uses the configured development domain on the app's `PORT`, allow that exact host-and-port as well. Do not allow all origins or broad Replit-domain suffixes.

**Why:** The app sits behind a proxy and can be visited through more than one Replit-hosted domain. A browser can retain `:5000` in its Origin even when the forwarded host omits it; exact configured-host fallbacks avoid legitimate registration/login failures without removing CSRF protection.

**How to apply:** Preserve exact host matching whenever changing the `/api` origin guard. Include configured development and published domains where available, plus only the configured development domain with the app port; verify that origin is accepted and an unrelated origin remains blocked.
