---
name: S999 change scope
description: The user's scope constraint for changes to the S999 game.
---

Only change the game screen or configuration the user explicitly names. Leave unrelated screens and behavior untouched.

**Why:** The user has repeatedly asked for narrow changes without modifying other parts of the game.

**How to apply:** Keep edits isolated to the requested page or configuration and add only the smallest supporting files needed.
