---
name: S999 virtual currency
description: S999 Demo Coin balances and non-cash wallet request requirements.
---

S999 is a play-only game. Wallet balances are Demo Coins; any PKR-style display is illustrative and must carry a clear non-cash notice. EasyPaisa and JazzCash bindings are separate, and withdrawal requests are virtual-only admin reviews. Approval does not send money; rejection returns the held Demo Coins.

**Why:** The user chose Demo Coins requests rather than real PKR payouts. Provider numbers are for identifying the requested method only; no payment API or cash transfer is authorized.

**How to apply:** Keep balances and stakes labeled as Demo Coins. Keep EasyPaisa and JazzCash accounts separate, snapshot the selected number on each request, send requests to the admin queue, and refund the reserved coins if rejected. Never describe approval as a payout.
