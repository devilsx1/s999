---
name: S999 wheel art assets
description: Preparing screenshot-derived Lucky Wheel art without checkerboard transparency artifacts.
---

Treat screenshot checkerboards as RGB pixels, not transparency. After editing or cropping wheel artwork, apply an explicit alpha mask and verify sampled pixels around the outside and center are actually transparent before using it in the game.

**Why:** Image-editing tools may preserve a transparency checkerboard as ordinary image pixels, and previews can make transparent areas look opaque. A grayscale mask is not automatically an alpha mask.

**How to apply:** When deriving wheel art from screenshots, inspect the output channel count and sample alpha values with ImageMagick. Keep both the outside of the wheel and its center hole transparent so UI overlays remain clean.
